<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Master_model extends CI_Model
{
	function __construct()
	{
        parent::__construct();
    }


	function getListPegawai($offset)
	{
		$sql = "SELECT a.id_pegawai, a.photo,  a.nama, a.nip, a.rumpun, a.tgl_masuk, b.nama as jabatan, c.nama as puskesmas 
			    FROM mst_pegawai a 
				LEFT JOIN mst_jabatan b ON a.jabatan = b.id 
				LEFT JOIN mst_puskesmas c ON a.id_puskesmas = c.id_puskesmas ORDER BY a.nama ASC LIMIT 25 OFFSET $offset";
		$qry = $this->db->query($sql);
        $row = $qry->result();
		return $row;
	}
	
	function getListPegawaiNonPNS($offset)
	{
		$sql = "SELECT a.id_pegawai, a.photo,  a.nama, a.nip, a.rumpun, a.tgl_masuk, b.nama as jabatan, c.nama as puskesmas 
			    FROM mst_pegawai a 
				LEFT JOIN mst_jabatan b ON a.jabatan = b.id 
				LEFT JOIN mst_puskesmas c ON a.id_puskesmas = c.id_puskesmas WHERE status_pegawai = 2  ORDER BY a.nama ASC LIMIT 1000 OFFSET $offset";
		$qry = $this->db->query($sql);
        $row = $qry->result();
		return $row;
	}
	
	 function getDataPegawai($limit = 100, $offset=0)
	 {
		$sql = "SELECT a.*, b.nama AS jabatan, c.pendidikan, d.nama AS puskesmas, e.masa_kerja,  a.masa_kerja_detail
		FROM mst_pegawai a
		LEFT JOIN mst_jabatan b ON a.jabatan=b.id
		LEFT JOIN mst_pendidikan c ON a.pendidikan=c.id
		LEFT JOIN mst_puskesmas d ON a.id_puskesmas =d.id_puskesmas
		LEFT JOIN mst_masa_kerja e ON a.masa_kerja =e.id 
		WHERE nip <> '001' AND status_pegawai = 2  
		GROUP BY a.nip
		order by a.jabatan ASC, tgl_masuk ASC  LIMIT $limit OFFSET $offset";
		
		//echo $sql;
		$qry = $this->db->query($sql);
		$row = $qry->result();
		return $row;
	 }
	 
	 function detailPegawai($id_pegawai)
	 {

		$sql = "SELECT a.nama, a.nip, a.rumpun, a.status_kerja, a.tgl_masuk, b.nama as jabatan, c.nama as puskesmas 
			    FROM mst_pegawai a 
				LEFT JOIN mst_jabatan b ON a.jabatan = b.id 
				LEFT JOIN mst_puskesmas c ON a.id_puskesmas = c.id_puskesmas WHERE id_pegawai = $id_pegawai";
		$qry = $this->db->query($sql);
        $row = $qry->result();
		return $row;
	
	 }
	 
	 function getListLaporanTKD($limit = 100, $offset=0)
	 {
		$sql = "SELECT a.*, b.nama AS jabatan
		FROM mst_pegawai a
		LEFT JOIN mst_jabatan b ON a.jabatan=b.id
		WHERE nip <> '001' AND status_pegawai = 2  AND status_kerja <> 2
		GROUP BY a.nip
		order by a.jabatan ASC, tgl_masuk ASC  LIMIT $limit OFFSET $offset";
		
		//echo $sql;
		$qry = $this->db->query($sql);
		$row = $qry->result();
		return $row;
	 }
	 
	
	function getMenu($usergroup)
	{
		
		$sql = "SELECT a.id, b.*
				FROM usergroupmenu a 
				LEFT JOIN mst_menu b ON a.id_menu = b.menu_id 
				WHERE id_group = $usergroup
				ORDER BY menu_id  ASC";

		$qry = $this->db->query($sql);
        $row = $qry->result();
		return $row;
	}
	
	
	function getNilaiAktifitas($id_pegawai, $bulan, $tahun)
	{
		$dataKinerja = $this->Ekin_model->getListKinerjaPegawai($id_pegawai, $bulan, $tahun);
		
		$hasilTotal       = 0;
		$hasilTotalValid  = 0;
		$hasilTotalReject = 0;
		
		for($a=0; $a < count($dataKinerja); $a++)
		{
			$volume  = $dataKinerja[$a]->volume;
			$waktu   = $dataKinerja[$a]->waktu;
			$status  = $dataKinerja[$a]->status;
			
			$total_volume = $volume*$waktu ;
			
			//yg disetujui
			if($status==1)
			{
				$totalValid = $volume*$waktu;
				$hasilTotalValid = $hasilTotalValid+$totalValid;
			}
			
			if($status==2)
			{
				$totalReject = $volume*$waktu;
				$hasilTotalReject = $hasilTotalReject+$totalReject;
			}
			
			
			$hasilTotal = $hasilTotal+$total_volume;
		}
		
		return $hasilTotalValid;
		
		
	}
	
	
	function getTotalJamKerja($bulan, $tahun)
	{
		$hariKerja  = $this->getJumlahHariKerja($bulan, $tahun);
		$jamKerja 	   = $hariKerja[0]->jam_kerja_perhari;
		$jumlah_hari   = $hariKerja[0]->jumlah_hari;
		$totalJam      = $jamKerja*$jumlah_hari;
		
		return $totalJam;
		
	}
	
	
	function getlastAbsen($id_pegawai)
	{
		$sql = "SELECT tanggal from ts_absensi where id_pegawai = '$id_pegawai' ORDER BY tanggal DESC";
		$qry = $this->db->query($sql);
        $row = $qry->result();
		
		if(count($row)==0)
		{
			$tanggal = 0;
		}else{
			$tgl = $row[0]->tanggal;
			$jam = date('H:i:s', strtotime($tgl));
			
			
			$tanggal = format_semi($tgl) .' &nbsp; '.$jam;
		}
		return $tanggal;
	}
	
	
	function num_data($id_validator)
	{
		$this->db->select('id_pegawai');
		$this->db->from('mst_pegawai');
		$this->db->where('status_pegawai', 2);
		$this->db->where('id_validator', $id_validator);
		$query = $this->db->get();
		$row = $query->num_rows();

		return $row;

	}
	
	
	function getDataEdit($id)
	{

		$this->db->select('*');
		$this->db->from('mst_kegiatan');
		$this->db->where('id', $id);
		$query = $this->db->get();
        $row = $query->result();

		return $row;

	}
	
	
	function num_aktifitas()
	{
		$this->db->select('*');
		$this->db->from('mst_kegiatan');
		$query = $this->db->get();
		$row = $query->num_rows();

		return $row;

	}
	
	function getDataListAktifitas($limit, $offset)
	{
		$this->db->select('*');
		$this->db->from('mst_kegiatan');
		$this->db->limit($limit, $offset);
		$this->db->order_by('nama_kegiatan', 'ASC');
		$query = $this->db->get();
        $row = $query->result();
		
		return $row;
	}
	
	
	
	function getDataListPegawai($id_validator, $limit, $offset)
	{
		$this->db->select('nama, nip, id_pegawai');
		$this->db->from('mst_pegawai');
		$this->db->where('status_pegawai', 2);
		$this->db->where('id_validator', $id_validator);
		$this->db->limit($limit, $offset);
		$this->db->order_by('nama', 'ASC');
		$query = $this->db->get();
        $row = $query->result();
		
		return $row;
	}
	
	
	function insertTS_absensi($tanggal,$nip, $transaksi)
	{
		
		$data = array(
				'tanggal' => $tanggal,
				'id_pegawai' => $nip,
				'transaksi' =>  $transaksi,
				'tgl_upload' => date('Y-m-d H:i:s'),
				'status' => 1,
				'id_puskesmas' => 1,
				
			);
			
		
			$this->db->insert('ts_absensi', $data);	
			
			return true;
	}
	
	function getIDPegawai($nama)
	{
		
		$sql = "SELECT id_pegawai FROM mst_pegawai WHERE nama like '%$nama%' limit 1";
		$query = $this->db->query($sql);
		$row = $query->result();

		return $row;

	}
			
				
	function getDataRekapLaporan($bulan='', $tahun='', $orderby='')
	{
		$sql = "SELECT a.*, b.nama,b.nip, b.nip, tgl_masuk, no_rekening, gaji, npwp, c.nama as jabatan
				FROM ts_rekap_tkd a
				LEFT JOIN mst_pegawai b ON a.id_pegawai = b.id_pegawai
				LEFT JOIN mst_jabatan c ON b.jabatan = c.id
				WHERE bulan = '$bulan' AND tahun = '$tahun' order by b.jabatan ASC, b.tgl_masuk ASC";
		$query = $this->db->query($sql);
		$row = $query->result();

		return $row;
	}
	function cekIDRekap($id_pegawai, $bulan, $tahun)
	{
		$sql = "SELECT id FROM ts_rekap_tkd WHERE id_pegawai = $id_pegawai AND bulan = '$bulan' AND tahun = '$tahun'";
		$query = $this->db->query($sql);
		$row = $query->result();

		return $row;
	}
	
	function getPerhitunganTKD($id_pegawai)
	{
		$this->db->select('*');
		$this->db->from('perhitungan_tkd');
		$this->db->where('id_pegawai', $id_pegawai);
		$query = $this->db->get();
		$row = $query->result();

		return $row;

	}
	
	function getDetPegawai($id_pegawai)
	{
	
		$query    = $this->db->get_where('mst_pegawai', array('id_pegawai' => $id_pegawai), 1, 0);
		$row      = $query->result();

		return $row;

	}

	function getPoinPerilaku($id_pegawai, $bulan, $tahun)
	{
	
	
		$this->db->select('sum(poin) as total');
		$this->db->from('penilaian_perilaku');
		$this->db->where('id_pegawai', $id_pegawai);
		$this->db->where('periode_bulan', $bulan);
		$this->db->where('periode_tahun', $tahun);
		$query = $this->db->get();
		$row      = $query->result();

		return $row;

	}
	
	
	
	function getDataTKD($id_pegawai)
	{
	
	
		$this->db->select('*');
		$this->db->from('perhitungan_tkd');
		$this->db->where('id_pegawai', $id_pegawai);
		$query = $this->db->get();
		$row      = $query->result();

		return $row;

	}
	
	public function getListValidator()
	{

		$this->db->select('validator.*, mst_pegawai.nama');
		$this->db->from('validator');
		$this->db->join('mst_pegawai', 'validator.id_pegawai = mst_pegawai.id_pegawai');

		$query = $this->db->get();
		$row = $query->result();

		return $row;

	}//end function


	public function getJumlahHariKerja($bulan, $tahun)
	{

		$query    = $this->db->get_where('mst_hari_kerja', array('bulan' => $bulan,'tahun' => $tahun), 1, 0);
		$row = $query->result();

		return $row;

	}//end function


	
	function cekPassword($id_pegawai, $password)
	{
		$query    = $this->db->get_where('mst_pegawai', array('id_pegawai' => $id_pegawai,'password' => $password), 1, 0);
		$row      = $query->result();
		$num_rows = $query->num_rows();
		
		if($num_rows == 0)
		{
			return false;
		}else{
			return true;
		}
		
	}
	
	function getTotalCapaian($id_pegawai, $bulan, $tahun)
	{
		$sql = "SELECT `tgl`, `jns_kegiatan`, `id_kegiatan`, status, a.volume,  b.waktu, SUM(a.volume*b.waktu)as total
FROM ts_kinerja a LEFT JOIN mst_kegiatan b on a.id_kegiatan = b.id
WHERE id_pegawai = $id_pegawai AND year(tgl) = '$tahun' AND month(tgl) = '$bulan' AND status = 1";

		$qry = $this->db->query($sql);
        $row = $qry->result();
		$capaian = $row[0]->total;
		
		
		return $capaian;


	}
	
	
	function getMasterCutiPegawai($id_pegawai)
	{
		
		
		$this->db->select('*');
		$this->db->from('mst_cuti_pegawai');
		$this->db->where('id_pegawai', $id_pegawai);
		$query = $this->db->get();
		$row      = $query->result();

		return $row;
	}
	//AND b.id_validator = '$id_validator'
	function getDataCuti($id_validator)
	{
	    $sql = "SELECT a.*, b. nama
	            FROM ts_cuti a 
	            LEFT JOIN mst_pegawai b ON a.id_pegawai = b.id_pegawai
				WHERE tgl_dari >= '2020-01-01' AND tgl_dari <= '2020-01-31' AND b.id_validator = '$id_validator'  ORDER BY a.id DESC";
	   	$qry = $this->db->query($sql);
        $row = $qry->result();
        
         return $row;
	    
	    
	}
	
	function getDataCutiAll()
	{
	    $sql = "SELECT a.*, b. nama
	            FROM ts_cuti a 
	            LEFT JOIN mst_pegawai b ON a.id_pegawai = b.id_pegawai
				WHERE tgl >= '2019-11-01' ORDER BY a.id DESC";
	   	$qry = $this->db->query($sql);
        $row = $qry->result();
        
         return $row;
	    
	    
	}
	
	function getAbsenMasuk($kode_pegawai, $bulan, $tahun)
	{
		 $sql = "SELECT tanggal FROM ts_absensi WHERE id_pegawai = '$kode_pegawai' AND month(tanggal) = '$bulan' AND year(tanggal) = '$tahun' ORDER BY tanggal ASC";
		 $qry = $this->db->query($sql);
         $row = $qry->result();
		 
		 return $row;
	}
	
	function insertHitungTelat($id_pegawai, $date_absen)
	{
		$split = explode(" ", $date_absen);
		$tgl_absen   = $split[0]; 
		$jam_absen   = $split[1];
		

		
		$jam_masuk = '07:30:00';
		
		$cekAbsen = $this->cekAbsen($id_pegawai, $tgl_absen);
		
		if($cekAbsen==0)
		{	
		    $telat = $this->hitung_telat($jam_absen, 1);
		
			$dataInsert = array(
			  'id_pegawai'=>$id_pegawai,
			  'tanggal_absen'=>$tgl_absen,
			  'jam_absen'=>$jam_absen,
			  'jam_masuk' => $jam_masuk,
			  'telat'=>$telat
			  
			);
			
			$this->db->insert('hitung_telat', $dataInsert);
		}
			
			
		
	}
	
	function UpdateTotalTelat($id_pegawai, $bulan, $tahun, $totalTelat)
	{
		 $sql = "UPDATE rekap_absensi SET terlambat = $totalTelat WHERE id_pegawai = '$id_pegawai' AND tahun = '$tahun' AND bulan = '$bulan'";
		 $qry = $this->db->query($sql);
		 
		 return  true;
	}
	
	
	
	function cekAbsen($id_pegawai, $tgl_absen)
	{
		 $sql = "SELECT id FROM hitung_telat WHERE id_pegawai = '$id_pegawai' AND tanggal_absen = '$tgl_absen'";
		 $qry = $this->db->query($sql);
         $num = $qry->num_rows();
		 
		 return $num;
	}
	
	
	function getDataTelat($id_pegawai, $bulan, $tahun)
	{

		 $sql = "SELECT sum(telat) as total_telat FROM hitung_telat WHERE id_pegawai = '$id_pegawai' 
		 AND month(tanggal_absen) = '$bulan' 
		 AND year(tanggal_absen) = '$tahun'";
		 $qry = $this->db->query($sql);
         $row = $qry->result();
		 
		// echo $sql;
		 
		 $telat = $row[0]->total_telat;
		 
		 
		 
		 return $telat;
	}
	
	#PC - Pulang Cepat
	function hitungPC($jamAbsen, $jamPulang)
	{
		
		$explod1 = explode(":", $jamAbsen);
		$explod2 = explode(":", $jamPulang);
		
		
		$jam01   = $explod1[0]; //jam
		$menit01 = $explod1[1]; //menit
		
		$jam02   = $explod2[0]; //jam
		$menit02 = $explod2[1]; //menit
		
		if($jam01 < $jam02) // klo jam absen kurang dari jam pulang
		{
			$menit = 60-$menit01;
			
			if($jam01==15)
			{
				$pc = $menit;
			}elseif($jam01==14){
				$pc = 60+$menit;
			}elseif($jam01==13){
				$pc = 120+$menit;
			}elseif($jam01==12){
				$pc = 180+$menit;
			}else{
				$pc=300;
			}
			
		}else{
			$pc= 0;
		}
		
	
		return $pc;
		
	}

	function hitung_telat($jam_absen_masuk, $shift = 9)
	{
		
		
//echo '<br> model:'.$jam_absen_masuk.'<p>&nbsp;</p>';
		$split = explode(":", $jam_absen_masuk);
		$jam   = $split[0]; 
		$menit = $split[1];
		

		$jamKerjaShift = $this->master_model->getJamKerjaShift($shift);
		//print_array( $jamKerjaShift);
		$jamMasuk  = $jamKerjaShift[0];
		$jamKeluar = $jamKerjaShift[1];
		
		if($jamMasuk=='off')
		{
			$telat = 0;
		}else{
			$split2 = explode(":", $jamMasuk);
			$jam2   = $split2[0]; 
			$menit2 = $split2[1];
			
			$jamAman = $jam2-1; // untuk mendapatkan sebelum jam masuknya
			
			
			if($jam > $jamAman)
			{
				
				$c = ($jam-$jam2)*60+$menit-$menit2;
				
				if($c < 0)
				{
					$telat = 0;
				}else{
					$telat = $c;
				}
				
			}else{
				$telat = 0;
			}
				
		}
	
	
		return $telat;
		
		
	}



	function insertDataRekapTelat($id_pegawai, $bulan, $tahun, $terlambat)
	{
	
		$cekRekap = $this->cekRekapAbsen($id_pegawai, $bulan, $tahun);
		
		if($cekRekap==false)
		{	
		   
			$dataInsert = array(
			  'id_pegawai'=>$id_pegawai,
			  'terlambat'=>$terlambat,
			  'tahun' => $tahun,
			  'bulan'=>$bulan,
			  'date_create' => date('Y-m-d H:i:s'),
			  
			);
			
			$this->db->insert('rekap_absensi', $dataInsert);
		}else{
			
			$this->db->where('id', $cekRekap);
			$this->db->set('terlambat', $terlambat);
			$this->db->update('rekap_absensi');
		}
			
		return true;
		
	}
	
	
	function cekRekapAbsen($id_pegawai, $bulan, $tahun)
	{
		 $sql = "SELECT id FROM rekap_absensi WHERE id_pegawai = '$id_pegawai' 
		 AND tahun = '$tahun' 
		 AND bulan = '$bulan'";
		 $qry = $this->db->query($sql);
         $row = $qry->num_rows();
	
		 if($row==0)
		 {
			 return false;
		 }else{
			 $id = $row[0]->id;
			 return $id;
		 }
		
		
		 
	}
	
	function cekRekapTKD($id_pegawai, $bulan, $tahun)
	{
		 $sql = "SELECT id FROM ts_rekap_tkd WHERE id_pegawai = '$id_pegawai'  AND tahun = '$tahun' AND bulan = '$bulan'";
		
		 $qry = $this->db->query($sql);
         $num = $qry->num_rows();
		 if($num==0)
		 {
			 return false;
		 }else{
			 $row = $qry->result();
			 $id = $row[0]->id;
			 return $id;
		 } 
	}
	
	
	function getRekapTKD($id)
	{
		 $sql = "SELECT * FROM ts_rekap_tkd WHERE id = $id";	 
		 $qry = $this->db->query($sql);
         $row = $qry->result();
			
		 return $row;
		 
	}
	
	
	
	function getHariLibur($tgl)
	{
		
		$query = $this->db->get_where('ts_hari_libur', array('tgl' => $tgl), 1, 0);
		$row   = $query->result();
		 
		return $row;
	}
	
	function getDataRekap($id_pegawai, $bulan, $tahun)
	{
		$this->db->where('id_pegawai', $id_pegawai);
		$this->db->where('tahun', $tahun);
		$this->db->where('bulan', $bulan);
		$query = $this->db->get('rekap_absensi');
		
		 
		return $query;
	}
	
	
	
	function cekJaga24Jam($id_pegawai, $bulan, $tahun)
	{
		if($bulan < 10)
		{
			$bulan = '0'.$bulan;
		}
		 $bulanTahun = $bulan.'-'.$tahun;
		 
	
		 $query = $this->db->get_where('petugas_24jam', array('id_pegawai' => $id_pegawai, 'bulan_tahun'=>$bulanTahun), 1, 0);
		 $row = $query->num_rows();
	
		 if($row==0)
		 {
			 return false;
		 }else{
		     return true;
		 }
		 
	}
	
	function cekShiftKerja($id_pegawai, $bulanTahun, $tgl)
	{

		 $query = $this->db->get_where('ts_shift_kerja ', array('id_pegawai' =>$id_pegawai, 'bulan_tahun'=>$bulanTahun, 'tanggal'=>$tgl), 1, 0);
		 $row = $query->result();
	
		 return $row;
		 
		 
	}
	
	
	function cekTableIzin($id_pegawai, $tgl)
	{
	
		 $query = $this->db->get_where('ts_absen_dl ', array('id_pegawai' =>$id_pegawai, 'tanggal'=>$tgl), 1, 0);
		 $row = $query->result();
	
		 return $row;
		 
		 
	}
	
	
	
	function getHariAbsenDL($tgl,$id_pegawai, $in_out)
	{
		 $tgl = format_db($tgl);
		
		 $sql = "SELECT * FROM ts_absen_dl WHERE id_pegawai = '$id_pegawai' AND tanggal = '$tgl'";
		 //echo $sql.'<br>';
		 $query = $this->db->query($sql);
		 $row   = $query->result();
	
		 return $row;
	}
	
	function getShiftKerjaPegawai($id_pegawai, $h, $bulan, $tahun)
	{
		
		 $bulanTahun = $bulan.'-'.$tahun;
		
		 $sql = "SELECT b.name 
		 FROM ts_shift_kerja  a
		 LEFT JOIN mst_shift_kerja b ON a.shift = b.shift
		 WHERE id_pegawai = '$id_pegawai' 
		 AND tanggal = '$h' AND bulan_tahun = '$bulanTahun'";
		 
		 $qry = $this->db->query($sql);
         $row = $qry->result();
		 $num = $qry->num_rows();
		
		 if($num==0)
		 {
			  $jadwal ='--';
		 }else{
			  $shift = $row[0]->name;
			  $jadwal = $shift;
			  
			  
		 }
		
		
		 return $jadwal;
		 
	}
	
	function insertAbsenDL($jns,  $id_pegawai, $tgl, $in_out, $keterangan, $getLastID)
	{
		
		$data = array(		
				'jns_absensi' => $jns,		
				'id_pegawai' => $id_pegawai,
				'id_cuti' => $getLastID,			
				'tanggal' => $tgl,
				'in_out' => $in_out,
				'keterangan' => $keterangan,
				'date_in' => date('Y-m-d H:i:s')
			);
		$this->db->insert('ts_absen_dl', $data);
		
		return true;
	}
	
	
	function insertPenilaianPerilaku($id_pegawai, $bulan, $tahun, $tgl, $id_item, $jns_item, $jawaban,$poin)
	{
			$data=array(
			   'id_pegawai'=>$id_pegawai,
			   'periode_bulan'=>$bulan,
			   'periode_tahun'=>$tahun,
			   'tgl_input'=>$tgl,
			   'id_pertanyaan'=>$id_item,
			   'jns_item'=>$jns_item,
			   'jawaban'=>$jawaban,
			   'poin'=>$poin,
			);
			
			//print_array($data);
			$this->db->insert('penilaian_perilaku', $data);
	}
	
	
	
	function getJamKerjaShift($shift)
	{
		 
		 
		 if($shift==0)
		 {
			 //hari libur
			 $masuk  = 'off';
			 $pulang = 'off';
		 }else{
			  #getShift
			 $sql2 = "SELECT * FROM mst_shift_kerja WHERE shift = '$shift'";
			 $qry2 = $this->db->query($sql2);
			 $row2 = $qry2->result();
			 
			 $masuk  = $row2[0]->jam_masuk;
			 $pulang = $row2[0]->jam_pulang;
		 }
		 
		 return array($masuk, $pulang);
		 
		
		 
	}
	
	function insertPetugas24Jam($id_pegawai, $bulan_tahun, $tgl)
	{
		
		$getIdPuskes  = $this->Ekin_model->select_in('mst_pegawai', 'id_puskesmas', " WHERE id_pegawai = '$id_pegawai'");
		$id_puskesmas = $getIdPuskes[0]->id_puskesmas;
		
		$cekPetugas = $this->cekPetugas($id_pegawai, $bulan_tahun);
		
		if($cekPetugas==0)
		{
			$data = array(		
					'id_pegawai' => $id_pegawai,			
					'jns_layanan' => 1,
					'id_puskesmas' => $id_puskesmas,
					'bulan_tahun' => $bulan_tahun
				);
			$this->db->insert('petugas_24jam', $data);
			
			//buat shift
			$jmlh_hari = date('t', strtotime($tgl));
			for($a=0; $a < $jmlh_hari; $a++)
			{
				
				$tanggal = $a+1;
				
				$this->Ekin_model->insert_jadwal_shift($tanggal, $id_pegawai, $shift=1, $bulan_tahun);
			}
			
		
			
		}
		
		
		
		
		return true;
	}
	
	function cekPetugas($id_pegawai, $bulan_tahun)
	{
			$query = $this->db->get_where('petugas_24jam', array('id_pegawai' => $id_pegawai, 'bulan_tahun'=>$bulan_tahun), 1, 0);
		    $row   = $query->num_rows();
			
			return $row;
	}
	
	function cekCuti($id_pegawai)
	{
		$this->db->select('*');
		$this->db->from('ts_cuti');
		$this->db->where('id', $id);
		$query = $this->db->get();
        $row = $query->result();
		
	}
	
	function getDetCuti($id)
	{

		$this->db->select('*');
		$this->db->from('ts_cuti');
		$this->db->where('id', $id);
		$query = $this->db->get();
        $row = $query->result();

		return $row;

	}
	
	
	function lastIDCuti()
	{
		$sql = "SELECT id FROM ts_cuti ORDER BY id DESC LIMIT 1 OFFSET 0";
		$qry = $this->db->query($sql);
		$row = $qry->result();
		$id  = $row[0]->id;
		
		$last_id = $id+1;
		
		return $last_id;
		
		
	}
	


}


?>