<?php ob_start();
defined('BASEPATH') OR exit('No direct script access allowed');
class Ekin_model extends CI_Model
{
	function __construct()
	{
        parent::__construct();
		//$this->db = $this->load->database('ekin', true);
    }
	function getValidUserData($nip, $password)
	{
		$query = $this->db->get_where('mst_pegawai', array('nip' => $nip, 'password' => $password), 1, 0);
        $row = $query->result();
		return $row;
	}
	
	
	function getDataJson($id_puskesmas=1, $bulan_tahun)
	{
	        $url        = "e-rakanita.com/ekin/api/getLastData?bulan_tahun=$bulan_tahun&id_puskesmas=$id_puskesmas";   
			$result     = $this->grabURL($url);
			//echo $result;
			//$res        = json_decode($result);
			return $result;
			//echo $res;
			
			
	}
	
	
	
	
	
	function getDataInputKinerjaPegawai($id_validator_session, $bulan, $tahun)
	{
		$sql = "SELECT a.id_pegawai, b.nama, b.nip FROM `ts_kinerja` a 
				LEFT JOIN mst_pegawai b ON a.id_pegawai = b.id_pegawai 
				WHERE b.id_validator ='$id_validator_session' and YEAR(tgl) = '$tahun' AND MONTH(tgl) = '$bulan'
				GROUP by id_pegawai ";
		$qry = $this->db->query($sql);
		$row = $qry->result();
		
		//echo $sql;
		return $row;
		
	}
	
	
	function grabURL($url, $Encode = true){

			// inisialisasi CURL
			$data = curl_init();
			// setting CURL
			curl_setopt($data, CURLOPT_RETURNTRANSFER, 1);
			curl_setopt($data, CURLOPT_URL, $url);
			// menjalankan CURL untuk membaca isi file
			$hasil = curl_exec($data);
			curl_close($data);

			

		return $hasil;

	}
	
	function getJumlahKegiatan($id_pegawai, $status=0, $bulan, $tahun)
	{
		$sql = "SELECT id FROM ts_kinerja WHERE id_pegawai = $id_pegawai AND  status = $status and YEAR(tgl) = '$tahun' AND MONTH(tgl) = '$bulan'";
		$qry = $this->db->query($sql);
        $num = $qry->num_rows();
		return $num;
	}
	
	
	
	
	
	function getListKinerjaPegawai($id_pegawai, $bulan, $tahun, $limit=0, $order_by = '')
	{
		if($limit==0)
		{
			$limit = '';
		}else{
		  $limit = "LIMIT  $limit";
		
		}
		
		if($order_by=='')
		{
			$order = 'tgl ASC, jam_mulai ASC';
		}else{
		   $order = " $order_by";
		
		}
		
		if(strlen($bulan)==1)
		{
			if($bulan < 10)
			{
				$bulan = '0'.$bulan;
			}
		}
		
		$sql ="SELECT a.*, b.nama_kegiatan, b.waktu
		FROM `ts_kinerja` a LEFT JOIN mst_kegiatan b on a.id_kegiatan = b.id
		WHERE `id_pegawai` = $id_pegawai and YEAR(tgl) = '$tahun' AND MONTH(tgl) = '$bulan' order by  $order $limit";
		
		$qry = $this->db->query($sql);
	    $row = $qry->result();

		return $row;
	}
	
	function cekKegiatan($id_aktifitas, $id_pegawai)
	{
		$sql ="SELECT id FROM aktifitas_pegawai WHERE id_pegawai = $id_pegawai AND id_aktifitas = $id_aktifitas";
		$qry = $this->db->query($sql);
		$row = $qry->result();
		if(!empty($row))
		{
			return true;
		}else{
			return false;
		}
	}
	
	function getDataKinerjaPegawai($id_pegawai)
	{
		$sql ="SELECT a.tgl, a.id, a.jam_mulai, b.nama_kegiatan, b.nama_kegiatan FROM ts_kinerja a left join mst_kegiatan b on a.id_kegiatan = b.id WHERE id_pegawai = $id_pegawai";
		$qry = $this->db->query($sql);
		$row = $qry->result();
		return $row;
	}
	public function cekSessionLogin()
	{
		# code...
		$UserID = $this->session->userdata('id_user');
		if($UserID=='')
		{
			redirect(base_url());
		}
	}
	
	function getListPegawai($limit, $offset)
	{
		$this->db->order_by('nama', 'ASC');
		return $query = $this->db->get('mst_pegawai', $limit,$offset)->result();	
	}
	
	function getJawaban($id_pegawai, $id, $bulan, $tahun )
	{
		$query = $this->db->get_where('penilaian_perilaku', array('id_pegawai' => $id_pegawai,'id_pertanyaan' => $id, 'periode_bulan'=>$bulan, 'periode_tahun' =>$tahun), 1, 0);
		$row = $query->result();
		if(!empty($row))
		{
			$jawaban = $row[0]->jawaban;
			return $jawaban;
		}else{
			return 0;
		}
	}
	
	
	
	
	
	
	
	function getValidator()
	{
		$sql ="SELECT a.id_pegawai, b.nama
		FROM validator a LEFT JOIN mst_pegawai b ON a.id_pegawai = b.id_pegawai
		WHERE a.id_pegawai <> 276  AND a.id_pegawai <> 285 ";
		$qry = $this->db->query($sql);
		$row = $qry->result();
		
		return $row;
	}
	
	
	function getValidatorLevel($id_pegawai)
	{
		$query = $this->db->get_where('validator', array('id_pegawai' => $id_pegawai), 1, 0);
        $row = $query->result();
		
		$level = $row[0]->level;
		return $level;
		
	}
	
	function getNameValidator($id_pegawai)
	{
		$query = $this->db->get_where('mst_pegawai', array('id_pegawai' => $id_pegawai), 1, 0);
        $row = $query->result();
		
		$num = $query->num_rows();
		if($num==0)
		{
			$nama = '';
		}else{
			$nama = $row[0]->nama;
		}
		
		
		return $nama;
		
	}	
	function getCutiPegawai()
	{
		
		$sql ="SELECT a.*, b.nama, b.nip FROM mst_cuti_pegawai a LEFT JOIN mst_pegawai b on a.id_pegawai = b.id_pegawai order by b.nama ASC";
		$qry = $this->db->query($sql);
		$row = $qry->result();
		
		return $row;
	}
	
	
	function getIDKegiatan($nama_keg, $waktu)
	{
		
		$sql = "SELECT * FROM mst_kegiatan WHERE nama_kegiatan = '$nama_keg' AND waktu = $waktu";
		$qry = $this->db->query($sql);
		$row = $qry->result();
		/*
		echo $sql;
		exit;
		
		
		$query = $this->db->get_where('mst_kegiatan', array('nama_kegiatan' => $nama_keg), 1, 0);
		$row = $query->result();*/
		if(!empty($row))
		{
			$id = $row[0]->id;
			return $id;
		}else{
			return 0;
		}
	}
	
	
	function cekJawaban($id_pegawai, $id, $bulan, $tahun )
	{
		$query = $this->db->get_where('penilaian_perilaku', array('id_pegawai' => $id_pegawai,'id_pertanyaan' => $id, 'periode_bulan'=>$bulan, 'periode_tahun' =>$tahun), 1, 0);
		$row = $query->result();
		if(!empty($row))
		{
			$id = $row[0]->id;
			return $id;
		}else{
			return 0;
		}
	}
	public function cekIDPegawai($nip)
	{
		$query = $this->db->get_where('mst_pegawai', array('nip' => $nip), 1, 0);
		$row = $query->result();
	   	return $row;
	}
	public function cekRecord($table, $id_jenis, $id_pegawai, $periode)
	{
		$query = $this->db->get_where($table, array('id_jns_absensi' => $id_jenis, 'id_pegawai' =>$id_pegawai, 'periode'=>$periode ), 1, 0);
		$result = $query->result();
	   	return $result;
	}
	function getJumlahHariPengurangan($id_pegawai, $periode)
	{
		$sql = "SELECT SUM(jmlh_hari) as jmlh_hari FROM ts_pengurangan WHERE id_pegawai = $id_pegawai AND periode = '$periode' AND id_jns_absensi <> 4";
		$query = $this->db->query($sql);
		$result = $query->result();
		$jumlah = $result[0]->jmlh_hari;
		return $jumlah;
	}
	function getJumlahHariPenambahan($id_pegawai, $periode)
	{
		$sql = "SELECT SUM(jmlh_hari) as jmlh_hari FROM ts_penambahan WHERE id_pegawai = $id_pegawai AND periode = '$periode' ";
		$query = $this->db->query($sql);
		$result = $query->result();
		$jumlah = $result[0]->jmlh_hari;
		return $jumlah;
	}
	public function getIDTs($table, $id_jenis, $id_pegawai, $periode)
	{
		$query  = $this->db->get_where($table, array('id_jns_absensi' => $id_jenis, 'id_pegawai' =>$id_pegawai, 'periode'=>$periode ), 1, 0);
		$result = $query->result();
		$id     = $result[0]->id;
	   	return $id;
	}
     function getJumlahKinerja($periode_bulan, $periode_tahun, $id_pegawai, $status)
	 {
		    if($status=='semua')
			{
				$andStatus = "";
			}else{
				if($status=='nol'){$newstatus=0;}else{$newstatus=$status;}
				$andStatus = "AND status = $newstatus";
			}
			/*$explode = explode("-", $date);
			$periode_bulan = $explode[1];
			$periode_tahun = $explode[0];*/
			$sql = "SELECT id FROM ts_kinerja WHERE id_pegawai = $id_pegawai $andStatus AND month(tgl) = '$periode_bulan' AND year(tgl) = '$periode_tahun' ORDER BY tgl ASC";
        
			$qry = $this->db->query($sql);
			$num = $qry->num_rows();
			return $num;
	 }
	 
	 
	 function getListKinerjaPegawaiPerhari($id_pegawai, $tgl)
	{

		$sql ="SELECT a.*, b.nama_kegiatan, b.waktu
		FROM `ts_kinerja` a LEFT JOIN mst_kegiatan b on a.id_kegiatan = b.id
		WHERE `id_pegawai` = $id_pegawai and tgl = '$tgl' order by tgl ASC, jam_mulai ASC ";
		$qry = $this->db->query($sql);
	    $row = $qry->result();
		return $row;
	}
	
	
	 
	 function getNumKinerjaPerhari($id_pegawai, $tgl)
	 {
		$sql = "SELECT id FROM ts_kinerja WHERE id_pegawai = $id_pegawai AND tgl = '$tgl' ";
	
		$query = $this->db->query($sql);
		$result = $query->num_rows();
		return $result;
		
	 }
	 
	 function getTotalInputKinerja($periode_bulan, $periode_tahun, $id_pegawai)
	 {
			$sql = "SELECT id FROM ts_kinerja WHERE id_pegawai = $id_pegawai AND month(tgl) = '$periode_bulan' AND year(tgl) = '$periode_tahun' ORDER BY tgl ASC";
			$qry = $this->db->query($sql);
			$num = $qry->num_rows();
			return $num;
	 }
	 
	 function getTotalBelum($periode_bulan, $periode_tahun, $id_pegawai)
	 {
			$sql = "SELECT id FROM ts_kinerja WHERE id_pegawai = $id_pegawai AND month(tgl) = '$periode_bulan' AND year(tgl) = '$periode_tahun' AND status > 0 ORDER BY tgl ASC";
        
			$qry = $this->db->query($sql);
			$num = $qry->num_rows();
			return $num;
	 }
	 
	 
	  function getNumAbsen($periode_bulan, $periode_tahun, $id_pegawai, $jns)
	 {
			$sql = "SELECT id FROM ts_absen_dl WHERE id_pegawai = $id_pegawai AND month(tanggal) = '$periode_bulan' AND year(tanggal) = '$periode_tahun' AND jns_absensi = $jns GROUP  BY tanggal";
		//echo $sql.'<br>';
			$qry = $this->db->query($sql);
			$num = $qry->num_rows();
			return $num;
	 }
	 
    function select_in($table, $select, $option)
	 {
			$sql = "SELECT $select FROM $table $option";
			//echo $sql.'<br>';
			$qry = $this->db->query($sql);
			$row = $qry->result();
			return $row;
	 }
	 function getKinerja($id_aktifitas, $id_user, $tgl)
	 {
		$sql = "SELECT * FROM ts_kinerja WHERE id_pegawai = $id_user AND tgl = '$tgl' AND id_kegiatan = $id_aktifitas";
		//echo $sql.'<br>';
		$qry = $this->db->query($sql);
		$row = $qry->result();
		return $row;
	 }
	 function getDataKegiatan($id_user, $tahun, $bulan)
	 {
	
		 $sql = "SELECT a.*, b.nama_kegiatan, b.waktu
		 FROM ts_kinerja a
		 LEFT JOIN mst_kegiatan b on a.id_kegiatan = b.id
		 WHERE id_pegawai = $id_user AND year(tgl)= '$tahun' AND month(tgl)= '$bulan' ORDER BY tgl ASC";
		//echo $sql.'<br>';
		 $qry = $this->db->query($sql);
		 $row = $qry->result();
		 return $row;
	 }
	 
	 
	 function getListPetugas24()
	 {
		 	
		$sql = "SELECT a.*, b.nama AS jabatan, c.pendidikan, d.nama AS puskesmas, e.masa_kerja,  a.masa_kerja_detail
		FROM mst_pegawai a
		LEFT JOIN mst_jabatan b ON a.jabatan=b.id
		LEFT JOIN mst_pendidikan c ON a.pendidikan=c.id
		LEFT JOIN mst_puskesmas d ON a.id_puskesmas =d.id_puskesmas
		LEFT JOIN mst_masa_kerja e ON a.masa_kerja =e.id 
		WHERE shift = 1
		GROUP BY a.nip
		order by a.nama ASC ";
		
		//echo $sql;
		$qry = $this->db->query($sql);
		$row = $qry->result();
		return $row;
	 }
	 
	 
	 function insert_jadwal_shift($tanggal, $id_pegawai, $shift, $bulan_tahun)
	 {
		 $data = array(					
				'tanggal' => $tanggal,
				'id_pegawai' => $id_pegawai,
				'shift' => $shift,
				'bulan_tahun' => $bulan_tahun
			);
			
			
		$this->db->insert('ts_shift_kerja', $data);
		
		return true;
	 }
	 
	  function getRakapTKD($id_pegawai, $bulan, $tahun)
	 {
			$sql = "SELECT * FROM ts_rekap_tkd WHERE id_pegawai = $id_pegawai AND bulan = '$bulan' AND tahun = '$tahun'";
			$qry = $this->db->query($sql);
			$row = $qry->result();
			return $row;
	 }
	 
	 function getRakapAbsensi($id_pegawai, $bulan, $tahun)
	 {
			$sql = "SELECT * FROM ts_rekap_absensi WHERE id_pegawai = $id_pegawai AND bulan = '$bulan' AND tahun = '$tahun'";
			$qry = $this->db->query($sql);
			$row = $qry->result();
			return $row;
	 }
	 
	 function cekRekapAbsen($id_pegawai, $bulan, $tahun)
	 {
			$sql = "SELECT id, date_update FROM ts_rekap_absensi WHERE id_pegawai = $id_pegawai AND bulan = '$bulan' AND tahun = '$tahun'";
			$qry = $this->db->query($sql);
			$row = $qry->result();
			return $row;
	 }
	 
	 function updateRekapanAbsensi($datapegawai, $bulan, $tahun)
	 {
		 
		
		 for($a=0; $a < count($datapegawai); $a++)
		{
			$nip        = $datapegawai[$a]->nip;
			$id_pegawai        = $datapegawai[$a]->id_pegawai;
		
			$kd_pegawai = substr($nip, -4);
			
			$checkRekap = $this->Ekin_model->cekRekapAbsen($id_pegawai, $bulan, $tahun);
				
				//print_array($checkRekap);
				if(!empty($checkRekap))
				{
					$id = $checkRekap[0]->id;
					$date_update = $checkRekap[0]->date_update;
					
					
		
					echo 'insert';
					//update data rekap
				    // $this->Ekin_model->updateRekapAbsensi($id_pegawai, $nip, $bulan, $tahun, $id);
					
				}else{
					
					echo 'update';
					// $this->Ekin_model->insertRekapAbsensi($id_pegawai, $nip, $bulan, $tahun);
					
				}
				
		
		}
		
		exit;
		return true;
		
	 }
	 
	 
	 
	 
	 function insertRekapAbsensi($id_pegawai, $nip, $bulan, $tahun)
	 {
		 
		 	
		$numDlAwal  = $this->Ekin_model->getNumAbsen($bulan, $tahun, $id_pegawai, 1);
		$numDlAkhir = $this->Ekin_model->getNumAbsen($bulan, $tahun, $id_pegawai, 2);
		$numDlPenuh = $this->Ekin_model->getNumAbsen($bulan, $tahun, $id_pegawai, 3);
		$cuti 		= $this->Ekin_model->getNumAbsen($bulan, $tahun, $id_pegawai, 4);
		$sakit 	    = $this->Ekin_model->getNumAbsen($bulan, $tahun, $id_pegawai, 5);
		$izin 		= $this->Ekin_model->getNumAbsen($bulan, $tahun, $id_pegawai, 6);
		
		$total_dl = $numDlAwal+$numDlAkhir+$numDlPenuh;
		
		$terlambat = $this->getTelatPerbulan($nip, $id_pegawai, $bulan, $tahun);
		
		$date_update = date('Y-m-d');
		
		 $data = array(					
				'id_pegawai' => $id_pegawai,
				'terlambat' => $terlambat,
				'sakit' => $sakit,
				'izin' => $izin,
				'cuti' => $cuti,
				'dl' => $total_dl,
				'bulan' => $bulan,	
				'tahun' => $tahun,
				'date_update' => $date_update
			);
			
			
		$this->db->insert('ts_rekap_absensi', $data);
		
		return true;
	 }
	 
	  
	 function updateRekapAbsensi($id_pegawai, $nip, $bulan, $tahun, $id)
	 {
		 
		 	
		$numDlAwal  = $this->Ekin_model->getNumAbsen($bulan, $tahun, $id_pegawai, 1);
		$numDlAkhir = $this->Ekin_model->getNumAbsen($bulan, $tahun, $id_pegawai, 2);
		$numDlPenuh = $this->Ekin_model->getNumAbsen($bulan, $tahun, $id_pegawai, 3);
		$cuti 		= $this->Ekin_model->getNumAbsen($bulan, $tahun, $id_pegawai, 4);
		$sakit 	    = $this->Ekin_model->getNumAbsen($bulan, $tahun, $id_pegawai, 5);
		$izin 		= $this->Ekin_model->getNumAbsen($bulan, $tahun, $id_pegawai, 6);
		
	
		
		$total_dl = $numDlAwal+$numDlAkhir+$numDlPenuh;

		$terlambat = $this->getTelatPerbulan($nip, $id_pegawai, $bulan, $tahun);
	
	
		$date_update = date('Y-m-d');
		
		 $data = array(					
				'terlambat' => $terlambat,
				'sakit' => $sakit,
				'izin' => $izin,
				'cuti' => $cuti,
				'dl' => $total_dl,
				'bulan' => $bulan,	
				'tahun' => $tahun,
				'date_update' => $date_update
			);
			
		
		$this->db->where('id', $id);	
		$this->db->update('ts_rekap_absensi', $data);
		
		return true;
	 }
	 
	 
	 function getTelatPerbulan($nip, $id_pegawai, $bulan, $tahun)
	 {
			$kd_pegawai = substr($nip, -4);
			$today = date('Y-m-d');

			$date = $tahun.'-'.$bulan.'-01';
			$jmlh_hari = date('t', strtotime($date)); 
		
	
	
			$bln_thn      = $bulan.'-'.$tahun;
			$detPegawai   = $this->master_model->getDetPegawai($id_pegawai);
			$shift 		  = $detPegawai[0]->shift;
			
			
		
			if($shift==1)
			{
				$dataReturn =  $this->hitungTelatShift($id_pegawai, $kd_pegawai, $jmlh_hari, $bulan, $tahun);
				
			}else{
			   $dataReturn =  $this->hitungTelatRegular($id_pegawai, $kd_pegawai, $jmlh_hari, $bulan, $tahun);
			}
	
	
		return $dataReturn;
	//echo $jmlh_hari.'<br>';
		  

	 }
	 
	 function hitungTelatRegular($id_pegawai, $kd_pegawai, $jmlh_hari, $bulan, $tahun)
	 {
		  $today = date('Y-m-d');
		  $shift_time = '9';
		  $telat_menit  = 0;
		  $totalTelat  = 0;
		  
			for($a=0; $a < $jmlh_hari; $a++)
			{
						$h = $a+1;
					
						$tgl_kerja = $tahun.'-'.$bulan.'-'.$h;
					
						$absenMasuk  =  $this->Ekin_model->getAbsesnsiPerhari($kd_pegawai, $tgl_kerja, 0);								
						$getHariAbsenDLMasuk  = array();
					
						if($absenMasuk <> 0)
						{
							$masuk  = date('H:i:s', strtotime($absenMasuk));
							
							//hitung telat (jam masuk, Shift kerja)
							$hitung_telat = $this->master_model->hitung_telat($masuk, $shift_time);
						}else{
							$hitung_telat   = 300;
							$getHariAbsenDLMasuk  = $this->master_model->getHariAbsenDL($tgl_kerja, $id_pegawai, 1);
	
						}
						
					
						if(!empty($getHariAbsenDLMasuk))
						{
							$hitung_telat   = 0;									
						}
						
						$getTglMerah  =  $this->master_model->getHariLibur($tgl_kerja);
						if(!empty($getTglMerah))
						{
							$hitung_telat    = 0;
							$pulangAkhir     = 0;
						}
						
						
						$tgl_format_db = format_db($tgl_kerja);
						
						$date1 = strtotime($tgl_format_db);
						$date2 = strtotime($today);
							
						if($date1  > $date2)
						{
							$hitung_telat = 0;
						
						}
						
						//echo $hitung_telat.'<br>';
						$hari = format_hari($tgl_kerja);
						if($hari=='Sabtu' || $hari=='Minggu' ){  $hitung_telat= 0; }
						
						
				
					   $telat_menit = $hitung_telat;
					   $totalTelat  = $totalTelat+$telat_menit;
				
							
						 
               }
			  // echo exit;			
			   return $totalTelat;
	 }
	 
	 function hitungTelatShift($id_pegawai, $kd_pegawai, $jmlh_hari, $bulan, $tahun)
	 {
		 
		    $today = date('Y-m-d');
		    $totalTelat  	= 0;
		    $bln_thn       = $bulan.'-'.$tahun;
		 	$totalTelat = 0;
		 
			for($a=0; $a < $jmlh_hari; $a++)
			{
					$h = $a+1;
					
					$tgl_kerja = $tahun.'-'.$bulan.'-'.$h;
					
					$absenMasuk  =  $this->Ekin_model->getAbsesnsiPerhari($kd_pegawai, $tgl_kerja, 0);								
					$getHariAbsenDLMasuk  = array();
					
					
					$absenMasuk  =  $this->Absensi_model->getAbsesnsiPerhari($kd_pegawai, $tgl_kerja, 0);
                    $absenPulang =  $this->Absensi_model->getAbsesnsiPerhari($kd_pegawai, $tgl_kerja, 1);
					$getShift    = $this->Absensi_model->getDataShift($id_pegawai, $h, $bln_thn);
				
					if(!empty($getShift))
					{
		
						  $shift_time = $getShift[0]->shift;	
					}else{
						  $shift_time = '9';
						
					}
	
					$telat_menit  = 0;
					
					if($absenMasuk <> 0)
					{
						$masuk  = date('H:i:s', strtotime($absenMasuk));
						$hitung_telat = $this->master_model->hitung_telat($masuk, $shift_time);
					}else{
						$hitung_telat   = 300;
						
						if($shift_time==5 || $shift_time==10)
						{
							$hitung_telat         = 0;
						}else{
							$hitung_telat         = 300;
						}
						
						$getHariAbsenDLMasuk  = $this->master_model->getHariAbsenDL($tgl_kerja, $id_pegawai, 1);

					}
					
					
					if(!empty($getHariAbsenDLMasuk))
					{
						$hitung_telat   = 0;									
					}
				 
				 
					if($shift_time==0 || $shift_time==4 )
					{
	
						$hitung_telat = 0;
						$pulangAkhir = 0;
			
					}
						
	   				  $totalTelat  = $totalTelat+$hitung_telat;
						
							
						 
               }
			   
			   return $totalTelat;
	 }

	 
	 
	 function update_jadwal_shift($id_shift, $shift_kerja)
	 {
		 
		 
		$this->db->where('id', $id_shift);
		$this->db->set('shift', $shift_kerja);
		$this->db->update('ts_shift_kerja');
		
		return true;
	 }
	 
	 
	 
	 function getShiftBulananPegawai($id_pegawai, $bulan_tahun)
	 {
		$sql = "SELECT * FROM ts_shift_kerja WHERE id_pegawai = $id_pegawai AND bulan_tahun = '$bulan_tahun'  ORDER BY tanggal";
		$qry = $this->db->query($sql);
		$row = $qry->result();
		return $row;
	 }
	 
	 function getDataKegiatanharian($id_user, $tgl)
	 {
	
		 $tglKegiatan = date('Y-m-d', strtotime($tgl));
		 $sql = "SELECT a.*, b.nama_kegiatan, b.waktu
		 FROM ts_kinerja a
		 LEFT JOIN mst_kegiatan b on a.id_kegiatan = b.id
		 WHERE id_pegawai = $id_user AND  tgl ='$tglKegiatan' ORDER BY jam_mulai ASC";
		//echo $sql.'<br>';
		$qry = $this->db->query($sql);
		 $row = $qry->result();
		 return $row;
	 }
	 
	 
	 
	 public function getNilaiAktifitas($bulan, $tahun, $id_pegawai)
	 {
			 $sql = "SELECT a.volume,  b.waktu
			 FROM ts_kinerja a
			 LEFT JOIN mst_kegiatan b on a.id_kegiatan = b.id
			 WHERE id_pegawai = $id_pegawai AND month(tgl) = '$bulan' AND year(tgl) ='$tahun' AND status = 1 ";
			 $qry = $this->db->query($sql);
			 $row = $qry->result();
			 //print_array( $row );
			 $total = 0;
			 $totalKinerja = 0;
			 for ($i=0; $i < count($row) ; $i++) {
			 	  $vol = $row[$i]->volume;
				  $waktu = $row[$i]->waktu;
					$total = $vol * $waktu;
					$totalKinerja = $totalKinerja +$total;
			 }
			 return $totalKinerja;
	 }
	 function getAktifitasTambahan($id_user, $tgl)
	 {
		$sql = "SELECT a.*, b.nama_kegiatan, b.waktu
		 FROM ts_kinerja a
		 LEFT JOIN mst_kegiatan b on a.id_kegiatan = b.id
		 WHERE id_pegawai = $id_user AND tgl = '$tgl' AND jns_kegiatan = 2";
		//echo $sql.'<br>';
		$qry = $this->db->query($sql);
		$row = $qry->result();
		return $row;
	 }
	 function getNamakegiatan($id_aktifitas)
	 {
		$sql = "SELECT nama_kegiatan FROM mst_kegiatan WHERE id = $id_aktifitas";
		$qry = $this->db->query($sql);
		$row = $qry->result();
		$nama = $row[0]->nama_kegiatan;
		return $nama;
	 }
	 function getAktifitasPegawai($id_pegawai)
	 {
		$sql = "SELECT a.*, b.nama_kegiatan, b.waktu
		FROM aktifitas_pegawai a
		LEFT JOIN mst_kegiatan b ON a.id_aktifitas = b.id WHERE a.id_pegawai = $id_pegawai
		order by a.id_aktifitas ASC";
		//echo $sql.'<br>';
		$qry = $this->db->query($sql);
		$row = $qry->result();
		return $row;
	 }
	 
	 
	 function getDataValidator()
	 {
		$sql = "SELECT a.*, b.nama_kegiatan, b.waktu
		FROM aktifitas_pegawai a
		LEFT JOIN mst_kegiatan b ON a.id_aktifitas = b.id WHERE a.id_pegawai = $id_pegawai
		order by a.id_aktifitas ASC";
		//echo $sql.'<br>';
		$qry = $this->db->query($sql);
		$row = $qry->result();
		return $row;
	 }
	 
	 
	  function getDataPegawaiByValidator($id_validator)
	 {
		
		$sql = "SELECT a.*, b.nama AS jabatan, c.pendidikan, d.nama AS puskesmas, e.masa_kerja,  a.masa_kerja_detail
		FROM mst_pegawai a
		LEFT JOIN mst_jabatan b ON a.jabatan=b.id
		LEFT JOIN mst_pendidikan c ON a.pendidikan=c.id
		LEFT JOIN mst_puskesmas d ON a.id_puskesmas =d.id_puskesmas
		LEFT JOIN mst_masa_kerja e ON a.masa_kerja =e.id 
		WHERE id_validator = $id_validator AND status_pegawai = 2
		GROUP BY a.nip
		order by a.nama ASC ";
		
		//echo $sql;
		$qry = $this->db->query($sql);
		$row = $qry->result();
		return $row;
	 }
	 
	 function getDataPegawai($limit = 100, $status_pegawai=2, $puskesmas=0, $jabatan=0)
	 {
		// echo $status_pegawai;
		 if($status_pegawai > 0)
		 {
			 $and1 = " AND status_pegawai = $status_pegawai";
		 }else{
			  $and1 = "";
		 }
		 
		 if($puskesmas > 0)
		 {
			 $and2 = " AND a.id_puskesmas = $puskesmas";
		 }else{
			 $and2 = "";
		 }
		 
		  
		 if($jabatan > 0)
		 {
			 $and3 = " AND jabatan = $jabatan";
		 }else{
			 $and3 = "";
		 }
		 
		$sql = "SELECT a.*, b.nama AS jabatan, c.pendidikan, d.nama AS puskesmas, e.masa_kerja,  a.masa_kerja_detail
		FROM mst_pegawai a
		LEFT JOIN mst_jabatan b ON a.jabatan=b.id
		LEFT JOIN mst_pendidikan c ON a.pendidikan=c.id
		LEFT JOIN mst_puskesmas d ON a.id_puskesmas =d.id_puskesmas
		LEFT JOIN mst_masa_kerja e ON a.masa_kerja =e.id 
		WHERE nip <> '001' $and1  $and2  $and3
		GROUP BY a.nip
		order by a.jabatan ASC, tgl_masuk ASC  LIMIT $limit OFFSET 0";
		
		//echo $sql;
		$qry = $this->db->query($sql);
		$row = $qry->result();
		return $row;
	 }
	 
	 
	  function getEditPegawai($id_pegawai)
	 {
		$sql = "SELECT a.*, a.pendidikan as id_pend, b.nama AS nama_jabatan, c.pendidikan, d.nama AS puskesmas, e.masa_kerja,  a.masa_kerja_detail
		FROM mst_pegawai a
		LEFT JOIN mst_jabatan b ON a.jabatan=b.id
		LEFT JOIN mst_pendidikan c ON a.pendidikan=c.id
		LEFT JOIN mst_puskesmas d ON a.id_puskesmas =d.id_puskesmas
		LEFT JOIN mst_masa_kerja e ON a.masa_kerja =e.id
		WHERE id_pegawai = $id_pegawai";
		//echo $sql;
		$qry = $this->db->query($sql);
		$row = $qry->result();
		return $row;
	 }
	 public function getPtkp($id)
	 {
		$dataPegawai = $this->select_in('mst_pegawai', '*', "WHERE id_pegawai = $id");
		$jabatan    = $dataPegawai[0]->jabatan;
		$tgl_masuk    = $dataPegawai[0]->tgl_masuk;
		$id_status    = $dataPegawai[0]->status;
		$id_pend    = $dataPegawai[0]->pendidikan;
		$id_masa_kerja    = $dataPegawai[0]->masa_kerja;
		$qry = $this->db->query("SELECT jumlah FROM mst_gaji WHERE id_masa_kerja = $id_masa_kerja AND id_pendidikan = $id_pend AND id_status = $id_status" );
		$row = $qry->result();
		$jumlah = $row[0]->jumlah;
		return $jumlah;
	 }
	function mst_last_id($table)
	{
		$sql = "SELECT (id + 1) AS id FROM $table ORDER BY id DESC LIMIT 1";
		$qry = $this->db->query($sql);
		$num = $qry->num_rows();
		if($num > 0)
		{
			$row = $qry->result_array();
			return $row[0]['id'];
		}else{
			return 1;
		}
	}
	function mst_last_id_2($table, $col)
	{
		$sql = "SELECT ($col + 1) AS id FROM $table ORDER BY $col DESC LIMIT 1";
		$qry = $this->db->query($sql);
		$num = $qry->num_rows();
		if($num > 0){
			$row = $qry->result_array();
			return $row[0]['id'];
		}else{
			return 1;
		}
	}
	  function search_pegawai_by($option)
	 {
		$sql = "SELECT a.*, b.nama AS jabatan, c.pendidikan, d.nama AS puskesmas, e.masa_kerja,  a.masa_kerja_detail
		FROM mst_pegawai a
		LEFT JOIN mst_jabatan b ON a.jabatan=b.id
		LEFT JOIN mst_pendidikan c ON a.pendidikan=c.id
		LEFT JOIN mst_puskesmas d ON a.id_puskesmas =d.id_puskesmas
		LEFT JOIN mst_masa_kerja e ON a.masa_kerja =e.id $option
		order by id_pegawai DESC";
		//echo $sql;
		$qry = $this->db->query($sql);
		$row = $qry->result();
		return $row;
	 }
	function masaKerja($tahun, $bulan, $hari)
	{
		$table = 'mst_masa_kerja';
		$where = "WHERE masa_kerja like '%$tahun%'";
		//8 tahn, 0 bulan 1 hari
		if($tahun%2==0 && $tahun > 1)
		{
			//klo angkanya genap
			if($bulan==0)
			{
				if($hari==0)
				{
					#ambil id 2
				$getID = $this->select_in($table, 'id', "WHERE end = $tahun ");
				}else{
					#ambil id 3
					$getID = $this->select_in($table, 'id', "WHERE start = $tahun ");
				}
			}else{
				$getID = $this->select_in($table, 'id', "WHERE start = $tahun ");
			}
		}else{
			$getID = $this->select_in($table, 'id', "WHERE $tahun between start AND end");
		}
		$id = $getID[0]->id;
		return $id;
	}
	 function mst_data($table, $orderby='id')
	 {
		$sql = "SELECT * FROM $table ORDER BY $orderby DESC";
		$qry = $this->db->query($sql);
		$row = $qry->result();
		return $row;
	 }
	 function dataKegiatan()
	 {
		$sql = "SELECT a.*, b.nama as jabatan FROM mst_kegiatan a LEFT JOIN mst_jabatan b ON a.id_jabatan = b.id ORDER BY id DESC";
		$qry = $this->db->query($sql);
		$row = $qry->result();
		return $row;
	 }
	function mst_data_edit($modul, $ID)
	{
		//$database = $this->session->userdata('db');
	//	$this->db = $this->load->database($database, true);
        $sql = "SELECT * FROM $modul WHERE id = $ID";
        $qry = $this->db->query($sql);
        $row = $qry->result();
		return $row;
	}
	function mst_update($table, $option, $ID)
	{
        $sql = "UPDATE $table SET $option WHERE id='$ID'";
        $qry = $this->db->query($sql);
	}
	public function getDetDetailAktifitas($id_aktifitas)
	{
			$sql ="SELECT a.*, b.nama, b.nip, c.nama_kegiatan, c.waktu
			FROM ts_kinerja a
			LEFT JOIN mst_pegawai b ON a.id_pegawai = b.id_pegawai
			LEFT JOIN mst_kegiatan c ON a.id_kegiatan = c.id
			WHERE a.id = $id_aktifitas";
			$qry = $this->db->query($sql);
			$row = $qry->result();
			return $row;
	}
	public function searchAktifitas($tgl, $status)
	{
		    if($status=='')
			{
				$and = "";
			}else{
				$and = "AND a.status = $status";
			}
			$sql ="SELECT a.*, b.nama, b.nip, c.nama_kegiatan, c.waktu
			FROM ts_kinerja a
			LEFT JOIN mst_pegawai b ON a.id_pegawai = b.id_pegawai
			LEFT JOIN mst_kegiatan c ON a.id_kegiatan = c.id
			WHERE a.tgl = '$tgl' $and ";
			$qry = $this->db->query($sql);
			$row = $qry->result();
			return $row;
	}
	
	function cekDataCuti($id_pegawai)
	{
		$sql ="SELECT id FROM mst_cuti_pegawai WHERE id_pegawai = $id_pegawai";
		$qry = $this->db->query($sql);
		$row = $qry->result();
		if(!empty($row))
		{
			return true;
		}else{
			return false;
		}
	}
	
	function insertSettingAbsensi($tgl_from, $tgl_to,$shift ,$jam_masuk , $jam_pulang, $keterangan)
	{
		 $data = array(
					'tgl_from' => format_db($tgl_from),
					'tgl_to' => format_db($tgl_to),
					'shift' => $shift,
					'jam_masuk' => $jam_masuk.':00',
					'jam_pulang' => $jam_pulang.':00',
					'keterangan' => $keterangan
			);
			$this->db->insert('setting_absensi', $data);
			return true;
	}
    function countKegiatan($id)
	{
		$sql = "SELECT id FROM mst_kegiatan WHERE id_jabatan = $id";
		$qry = $this->db->query($sql);
		$row = $qry->num_rows();
		return $row;
	 }
	function do_upload($imgName)
	{
		$config['file_name']      = $imgName;
		$config['upload_path']    = './uploads/photo/';
		$config['allowed_types']  = 'gif|jpg|png|';
		$config['max_size']	      = '1500';
		$config['max_width']      = '1500';
		$config['max_height']     = '1500';
		$this->upload->initialize($config);
		$upload =$this->upload->do_upload('imageupload');
		if(!$upload)
		{
			$data = array('error' => $this->upload->display_errors('',''));
			$error = $data['error'];
		}else{
			$error = "";
		}
		return $error;
	}
	
	
	 function Parse_Data($data,$p1,$p2){
			$data=" ".$data;
			$hasil="";
			$awal=strpos($data,$p1);
			if($awal!=""){
				$akhir=strpos(strstr($data,$p1),$p2);
				if($akhir!=""){
					$hasil=substr($data,$awal+strlen($p1),$akhir-strlen($p1));
				}
			}
			return $hasil;	
	
	 }
	 
	 function insertDataAbsen()
	 {
		 
		 //$this->print_array($_POST);
		
		 
		 
		 $userId     = $_POST['userId'];
		 $DateTime   = $_POST['DateTime'];
		 $Status	 = $_POST['Status'];
		 $tgl = date('Y-m-d H:i:s');
		 
		 
		 for($a=0; $a < count($userId); $a++)
		 {
			 $UID 		    = $userId[$a];
			 $jam 			= $DateTime[$a];
			 $masuk_pulang  = $Status[$a];
			 
			 $tgl_input = date('Y-m-d', strtotime($jam));
				
			if($UID <> '')
			{	 
				 $cekTgl = $this->cekTglInput($tgl_input, $UID, $masuk_pulang);
				 
				// echo $cekTgl.'<br>';
				 if($cekTgl==0)
				 {
					 
					 $sql = "INSERT INTO ts_absensi (tanggal, id_pegawai, transaksi, tgl_upload) 
									   values ('" .$jam."',
										'" .$UID."','" .$masuk_pulang."', 
										'" .$tgl."' )";
			
					$result = $this->db->query($sql);	
					 
				 }
			}
			 
			
			 
		 }
		 
		return true;
	 }
	 
	 function getAbsenHarianMasuk($id_pegawai, $tgl)
	 {
			$sql = "SELECT tanggal FROM ts_absensi WHERE id_pegawai = '$id_pegawai' AND date(tanggal) = '$tgl' ORDER BY tanggal ASC limit 1";
			$qry = $this->db->query($sql);
			$row = $qry->result();
			
			if(count($row)>0)
			{
				$tanggal  = $row[0]->tanggal;
				$newDate  = $this->cekJamMasuk($tanggal);
				
				return $newDate;
			}else{
				return 0;
			}
			
	 }
	 
	 function getAbsenHarianPulang($id_pegawai, $tgl)
	 {
			$sql = "SELECT tanggal FROM ts_absensi WHERE id_pegawai = '$id_pegawai' AND date(tanggal) = '$tgl' ORDER BY tanggal DESC limit 1";
			$qry = $this->db->query($sql);
			$row = $qry->result();
			
			if(count($row)>0)
			{
				$tanggal  = $row[0]->tanggal;
				$newDate  = $this->cekJamKeluar($tanggal);
				return $newDate;
			}else{
				return 0;
			}
			
	 }
	 
	 
	 
	
	
	function getDailyAbsensi($id_pegawai, $tgl)
	{
		$sql = "SELECT tanggal FROM ts_absensi WHERE id_pegawai = '$id_pegawai' AND date(tanggal) = '$tgl'  AND transaksi = 0 ORDER BY  tanggal ASC limit 1";
		$qry = $this->db->query($sql);
		$row = $qry->result();

		$sql2 = "SELECT tanggal FROM ts_absensi WHERE id_pegawai = '$id_pegawai' AND date(tanggal) = '$tgl' AND transaksi = 1 ORDER BY  tanggal DESC limit 1";
		$qry2 = $this->db->query($sql2);
		$row2 = $qry2->result();
		
		if(count($row)>0)
		{
			$tanggal = $row[0]->tanggal;
			
		}else{
			$tanggal = 0;
		}
		
		if(count($row2)>0)
		{
			$tanggal2 = $row2[0]->tanggal;
			
		}else{
			$tanggal2 =  0;
		}
		
		
		return array($tanggal, $tanggal2);
	}
	 
	 
	 
	function getAbsesnsiPerhari($id_pegawai, $tgl, $status)
	{	
	    if($status==0)
		{
			$order_by = "tanggal ASC limit 1";
			$and = "AND transaksi = 0";
		}else{
			$order_by = "tanggal DESC limit 1";
			$and = "AND transaksi = 1";
		}
		

	    $sql = "SELECT tanggal FROM ts_absensi WHERE id_pegawai like '$id_pegawai' AND date(tanggal) = '$tgl' ORDER BY  $order_by";
		
		/*echo $sql;
		echo '<br>';*/
		
        $qry = $this->db->query($sql);
        $row = $qry->result();
		
		if(count($row)>0)
		{
			$tanggal = $row[0]->tanggal;
			
			if($status==0)
			{
				//masuk
				$newDate = $this->cekJamMasuk($tanggal);
			}else{
				//pulang
				$newDate  = $this->cekJamKeluar($tanggal);
			
			}
			
			
			return $newDate;
		}else{
			return 0;
		}
		
		
	}
	
	
	 function cekJamMasuk($date)
	 {
		 $expl = explode(":", $date);
		 $time = $expl[0];
		 
		 $time = substr($time, 11, 2);
		 	
		 
		 if($time > 13)
		 {
			 $newTime = '';
		 }else{
			 $newTime = $date;
		 }
		 
		 if($date=='')
		 {
			 $newTime = 0;
		 }
		 
		 return $newTime;
	 }
	 
	  function cekJamKeluar($date)
	 {
		 
		 
		 $expl = explode(":", $date);
		 $time = $expl[0];
		 $time = substr($time, 11, 2);
		 
		 if($time < 13)
		 {
			 $newTime = '';
		 }else{
			 $newTime = $date;
		 }
		 
		  if($date=='')
		 {
			 $newTime = 0;
		 }
		 
		 return $newTime;
	 }
	
	
	
	
	
	
	
	
	
	 function getDataAbsesnsiPegawai($id_pegawai)
	{
		$tahun = '2018';
		$bulan = '02';
        $sql = "SELECT * FROM `log_upload_absensi` WHERE id_pegawai = '$id_pegawai' AND year(tgl_absen) ='$tahun' AND month(tgl_absen) = '$bulan'  ORDER BY tgl_absen ASC ";
        $qry = $this->db->query($sql);
        $row = $qry->result();
		return $row;
	}
	
	 public function cekTglInput($tgl, $UID, $Status)
     {		
			
		    $query  = "SELECT id from ts_absensi  WHERE date(tanggal) = '$tgl' AND id_pegawai = '$UID' AND transaksi  = '$Status' ";
			$result = $this->db->query($query);
			$num 	= mysqli_num_rows($result);
			
			
		  return  $num;
     }
	 
	 
	 
	 
	function cekKegPeg($id_peg, $id_akt)
	{
		
		$sql = "SELECT id FROM aktifitas_pegawai WHERE id_pegawai = '$id_peg' AND id_aktifitas = $id_akt";
		$qry = $this->db->query($sql);
		$row = $qry->num_rows();
	
		if($row ==0)
		{
			return false;
		}else{
			return true;
		}
	}
	
	 
	
	
	
}
?>
