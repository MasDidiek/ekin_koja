<?php ob_start();
defined('BASEPATH') OR exit('No direct script access allowed');
class Absensi_model extends CI_Model
{
	function __construct()
	{
        parent::__construct();
		//$this->db = $this->load->database('ekin', true);
    }

	
	
	
	
	
	
	 
	  function getNumAbsen($periode_bulan, $periode_tahun, $id_pegawai, $jns)
	 {
			$sql = "SELECT id FROM ts_absen_dl WHERE id_pegawai = $id_pegawai AND month(tanggal) = '$periode_bulan' AND year(tanggal) = '$periode_tahun' AND jns_absensi = $jns";
			echo $sql.'<br>';
			$qry = $this->db->query($sql);
			$num = $qry->num_rows();
			return $num;
	 }
	 
   
	 
	 function getListPetugas24()
	 {
		 	
		$sql = "SELECT a.*, b.nama AS jabatan, c.pendidikan, d.nama AS puskesmas, e.masa_kerja,  a.masa_kerja_detail
		FROM mst_pegawai a
		LEFT JOIN mst_jabatan b ON a.jabatan=b.id
		LEFT JOIN mst_pendidikan c ON a.pendidikan=c.id
		LEFT JOIN mst_puskesmas d ON a.id_puskesmas =d.id_puskesmas
		LEFT JOIN mst_masa_kerja e ON a.masa_kerja =e.id 
		WHERE shift = 1
		GROUP BY a.nip
		order by a.nama ASC ";
		
		//echo $sql;
		$qry = $this->db->query($sql);
		$row = $qry->result();
		return $row;
	 }
	 
	 
	 function insert_jadwal_shift($tanggal, $id_pegawai, $shift, $bulan_tahun)
	 {
		 $data = array(					
				'tanggal' => $tanggal,
				'id_pegawai' => $id_pegawai,
				'shift' => $shift,
				'bulan_tahun' => $bulan_tahun
			);
			
			
		$this->db->insert('ts_shift_kerja', $data);
		
		return true;
	 }
	 
	 
	 function getRakapAbsensi($id_pegawai, $bulan, $tahun)
	 {
			$sql = "SELECT * FROM ts_rekap_absensi WHERE id_pegawai = $id_pegawai AND bulan = '$bulan' AND tahun = '$tahun'";
			$qry = $this->db->query($sql);
			$row = $qry->result();
			return $row;
	 }
	 
	 function cekRekapAbsen($id_pegawai, $bulan, $tahun)
	 {
			$sql = "SELECT id, date_update FROM ts_rekap_absensi WHERE id_pegawai = $id_pegawai AND bulan = '$bulan' AND tahun = '$tahun'";
			$qry = $this->db->query($sql);
			$row = $qry->result();
			return $row;
	 }
	 
	 function updateRekapanAbsensi($datapegawai, $bulan, $tahun)
	 {
		 
		
		 for($a=0; $a < count($datapegawai); $a++)
		{
			$nip        = $datapegawai[$a]->nip;
			$id_pegawai        = $datapegawai[$a]->id_pegawai;
		
			$kd_pegawai = substr($nip, -4);
			
			$checkRekap = $this->Ekin_model->cekRekapAbsen($id_pegawai, $bulan, $tahun);
				
				//print_array($checkRekap);
				if(!empty($checkRekap))
				{
					$id = $checkRekap[0]->id;
					$date_update = $checkRekap[0]->date_update;
					
					
		
					echo 'insert';
					//update data rekap
				    // $this->Ekin_model->updateRekapAbsensi($id_pegawai, $nip, $bulan, $tahun, $id);
					
				}else{
					
					echo 'update';
					// $this->Ekin_model->insertRekapAbsensi($id_pegawai, $nip, $bulan, $tahun);
					
				}
				
		
		}
		
		exit;
		return true;
		
	 }
	 
	 
	 
	 
	 function insertRekapAbsensi($id_pegawai, $nip, $bulan, $tahun)
	 {
		 
		 	
		$numDlAwal  = $this->Ekin_model->getNumAbsen($bulan, $tahun, $id_pegawai, 1);
		$numDlAkhir = $this->Ekin_model->getNumAbsen($bulan, $tahun, $id_pegawai, 2);
		$numDlPenuh = $this->Ekin_model->getNumAbsen($bulan, $tahun, $id_pegawai, 3);
		$cuti 		= $this->Ekin_model->getNumAbsen($bulan, $tahun, $id_pegawai, 4);
		$sakit 	    = $this->Ekin_model->getNumAbsen($bulan, $tahun, $id_pegawai, 5);
		$izin 		= $this->Ekin_model->getNumAbsen($bulan, $tahun, $id_pegawai, 6);
		
		$total_dl = $numDlAwal+$numDlAkhir+$numDlPenuh;
		
		$terlambat = $this->countTelat($id_pegawai, $bulan, $tahun);
		
		$date_update = date('Y-m-d');
		
		 $data = array(					
				'id_pegawai' => $id_pegawai,
				'terlambat' => $terlambat,
				'sakit' => $sakit,
				'izin' => $izin,
				'cuti' => $cuti,
				'dl' => $total_dl,
				'bulan' => $bulan,	
				'tahun' => $tahun,
				'date_update' => $date_update
			);
			
			
		$this->db->insert('ts_rekap_absensi', $data);
		
		return true;
	 }
	 
	  
	 function updateRekapAbsensi($id_pegawai, $nip, $bulan, $tahun, $id)
	 {
		 
		 	
		$numDlAwal  = $this->getNumAbsen($bulan, $tahun, $id_pegawai, 1);
		$numDlAkhir = $this->getNumAbsen($bulan, $tahun, $id_pegawai, 2);
		$numDlPenuh = $this->getNumAbsen($bulan, $tahun, $id_pegawai, 3);
		$cuti 		= $this->getNumAbsen($bulan, $tahun, $id_pegawai, 4);
		$sakit 	    = $this->getNumAbsen($bulan, $tahun, $id_pegawai, 5);
		$izin 		= $this->getNumAbsen($bulan, $tahun, $id_pegawai, 6);
		

		$total_dl = $numDlAwal+$numDlAkhir+$numDlPenuh;
		
		$terlambat = $this->countTelat($id_pegawai, $bulan, $tahun);
		
		$date_update = date('Y-m-d');
		
		 $data = array(					
				'terlambat' => $terlambat,
				'sakit' => $sakit,
				'izin' => $izin,
				'cuti' => $cuti,
				'dl' => $total_dl,
				'bulan' => $bulan,	
				'tahun' => $tahun,
				'date_update' => $date_update
			);
		
		
		$this->db->where('id', $id);	
		$this->db->update('ts_rekap_absensi', $data);
		
		return true;
	 }
	 
	 
	 function countTelat($id_pegawai, $bulan, $tahun)
	 {
		 
		
		 $absensi_harian = $this->Absensi_model->getDataAbsenHarian($id_pegawai, $bulan, $tahun);
		
		 
		 
			$totalTelat    = 0;
			$totalPC 	   = 0;
			$totalJamKerja = 0;
			
			for($a=0; $a < count($absensi_harian); $a++)
			{
				  $telatMenit = $absensi_harian[$a]->terlambat;
				  $totalTelat = $totalTelat+$telatMenit;
				  
				  
			}
			
			
			return $totalTelat;
		 
	 }
	 
	 
	 
	 function getTelatPerbulan($nip, $id_pegawai, $bulan, $tahun)
	 {
			$kd_pegawai = substr($nip, -4);
			$today = date('Y-m-d');

			$date = $tahun.'-'.$bulan.'-01';
			$jmlh_hari = date('t', strtotime($date)); 
			$totalTelat = 0;
	
		  
			for($a=0; $a < $jmlh_hari; $a++)
			{
					$h = $a+1;
					
					$tgl_kerja = $tahun.'-'.$bulan.'-'.$h;
					
					$absenMasuk  =  $this->Ekin_model->getAbsesnsiPerhari($kd_pegawai, $tgl_kerja, 0);								
					$getHariAbsenDLMasuk  = array();
					
					$telat_menit  = 0;
					
					if($absenMasuk <> 0)
					{
						$masuk  = date('H:i:s', strtotime($absenMasuk));
						$hitung_telat = $this->master_model->hitung_telat($masuk, 1);
					}else{
						$hitung_telat   = 300;
						$getHariAbsenDLMasuk  = $this->master_model->getHariAbsenDL($tgl_kerja, $id_pegawai, 1);

					}
					

					if(!empty($getHariAbsenDLMasuk))
					{
						$hitung_telat   = 0;									
					}
				 
				  
				  $tgl_format_db = format_db($tgl_kerja);
				  
				  $date1 = strtotime($tgl_format_db);
				  $date2 = strtotime($today);

				  if($date1  > $date2)
				  {
					  $hitung_telat = 0;
					  $btn_add_ket='';
				  }

				  $hari = format_hari($tgl_kerja);
   
				  if($hari=='Sabtu' || $hari=='Minggu' ){  $hitung_telat= 0; }
				  
				   $telat_menit = $hitung_telat;
				   $totalTelat  = $totalTelat+$telat_menit;
						
							
						 
               }
			   
			   return $totalTelat;

	 }
	 
	 

	 
	 
	 function update_jadwal_shift($id_shift, $shift_kerja)
	 {
		 
		 
		$this->db->where('id', $id_shift);
		$this->db->set('shift', $shift_kerja);
		$this->db->update('ts_shift_kerja');
		
		return true;
	 }
	 
	 
	 function getDataRaw($pin, $tgl)
	 {
		$sql = "SELECT * FROM ts_absensi WHERE id_pegawai = $pin AND tanggal like '$tgl%'  ORDER BY tanggal";
		
		$qry = $this->db->query($sql);
		$row = $qry->result();
		return $row;
	 }
	 
	 function getShiftBulananPegawai($id_pegawai, $bulan_tahun)
	 {
		$sql = "SELECT * FROM ts_shift_kerja WHERE id_pegawai = $id_pegawai AND bulan_tahun = '$bulan_tahun'  ORDER BY tanggal";
		$qry = $this->db->query($sql);
		$row = $qry->result();
		return $row;
	 }
	 
	 function getDataKegiatanharian($id_user, $tgl)
	 {
	
		 $tglKegiatan = date('Y-m-d', strtotime($tgl));
		 $sql = "SELECT a.*, b.nama_kegiatan, b.waktu
		 FROM ts_kinerja a
		 LEFT JOIN mst_kegiatan b on a.id_kegiatan = b.id
		 WHERE id_pegawai = $id_user AND  tgl ='$tglKegiatan' ORDER BY jam_mulai ASC";
		//echo $sql.'<br>';
		$qry = $this->db->query($sql);
		 $row = $qry->result();
		 return $row;
	 }
	 
	 
	 

	function insertSettingAbsensi($tgl_from, $tgl_to,$shift ,$jam_masuk , $jam_pulang, $keterangan)
	{
		 $data = array(
					'tgl_from' => format_db($tgl_from),
					'tgl_to' => format_db($tgl_to),
					'shift' => $shift,
					'jam_masuk' => $jam_masuk.':00',
					'jam_pulang' => $jam_pulang.':00',
					'keterangan' => $keterangan
			);
			$this->db->insert('setting_absensi', $data);
			return true;
	}
   
	 function insertDataAbsen()
	 {
		 
		 //$this->print_array($_POST);
		
		 
		 
		 $userId     = $_POST['userId'];
		 $DateTime   = $_POST['DateTime'];
		 $Status	 = $_POST['Status'];
		 $tgl = date('Y-m-d H:i:s');
		 
		 
		 for($a=0; $a < count($userId); $a++)
		 {
			 $UID 		    = $userId[$a];
			 $jam 			= $DateTime[$a];
			 $masuk_pulang  = $Status[$a];
			 
			 $tgl_input = date('Y-m-d', strtotime($jam));
				
			if($UID <> '')
			{	 
				 $cekTgl = $this->cekTglInput($tgl_input, $UID, $masuk_pulang);
				 
				// echo $cekTgl.'<br>';
				 if($cekTgl==0)
				 {
					 
					 $sql = "INSERT INTO ts_absensi (tanggal, id_pegawai, transaksi, tgl_upload) 
									   values ('" .$jam."',
										'" .$UID."','" .$masuk_pulang."', 
										'" .$tgl."' )";
			
					$result = $this->db->query($sql);	
					 
				 }
			}
			 
			
			 
		 }
		 
		return true;
	 }
	 
	 
	  function getDataEditAbsenHarian($id)
	 {
		 
		$this->db->select('*');
		$this->db->from('absensi_harian');
		$this->db->where('id', $id);	
		$query  = $this->db->get();
		$data   = $query->result();
		
		return $data;
		
	 }
	 
	 
	  function getDataAbsenHarian($id_pegawai, $bulan, $tahun)
	 {
		 
		$this->db->select('*');
		$this->db->from('absensi_harian');
		$this->db->where('id_pegawai', $id_pegawai);
		$this->db->where('bulan', $bulan);
		$this->db->where('tahun', $tahun);
		
		$query  = $this->db->get();
		$data   = $query->result();
		
		
		return $data;
		
	 }
	 
	 
	 function cekDataAbsensi($id_pegawai, $tgl, $bulan, $tahun)
	 {
		 
		$this->db->select('id');
		$this->db->from('absensi_harian');
		$this->db->where('id_pegawai', $id_pegawai);
		$this->db->where('tgl', $tgl);
		$this->db->where('bulan', $bulan);
		$this->db->where('tahun', $tahun);
		
		$query = $this->db->get();
		$num   = $query->num_rows();
		
		if($num==0)
		{
			return false;
		}else{
			return true;
		}
		
	 }
	 
	 function getIDDataAbsenHarian($id_pegawai, $tgl, $bulan, $tahun)
	 {
		 
		$this->db->select('id');
		$this->db->from('absensi_harian');
		$this->db->where('id_pegawai', $id_pegawai);
		$this->db->where('tgl', $tgl);
		$this->db->where('bulan', $bulan);
		$this->db->where('tahun', $tahun);
		
		$query  = $this->db->get();
		$data   = $query->result();
		$id     = $data[0]->id;
		
		return $id;
		
	 }
	 
	
	function getabsenMasuk($id_pegawai, $tgl)
	{
		$this->db->select('tanggal, id_pegawai');
		$this->db->from('ts_absensi');
		$this->db->where('id_pegawai', $id_pegawai);
		//$this->db->where('transaksi', 0);
		$this->db->like('tanggal', $tgl, 'after'); 
		$this->db->order_by('tanggal', 'ASC');
		$this->db->limit(1); 
		
		$query = $this->db->get();
		$num   = $query->num_rows();
		$row   = $query->result();
		
		;
		
		if($num==0)
		{
			return '-';
		}else{
			$tanggal = $row[0]->tanggal;
			$jam = date('H:i:s', strtotime($tanggal));
			return $jam;
		}

	}
	
	
	function getabsenKeluar($id_pegawai, $tgl)
	{
		$this->db->select('tanggal, id_pegawai');
		$this->db->from('ts_absensi');
		$this->db->where('id_pegawai', $id_pegawai);
		//$this->db->where('transaksi', 0);
		$this->db->like('tanggal', $tgl, 'after'); 
		$this->db->order_by('tanggal', 'DESC');
		$this->db->limit(1); 
		
		$query = $this->db->get();
		$num   = $query->num_rows();
		$row   = $query->result();
		
		if($num==0)
		{
			return '-';
		}else{
			$tanggal = $row[0]->tanggal;
			$jam = date('H:i:s', strtotime($tanggal));
			return $jam;
		}

	}
	 
	 
	 function getAbsenHarianMasuk($id_pegawai, $tgl)
	 {
			$sql = "SELECT tanggal FROM ts_absensi WHERE id_pegawai = '$id_pegawai' AND date(tanggal) = '$tgl' ORDER BY tanggal ASC limit 1";
			$qry = $this->db->query($sql);
			$row = $qry->result();
			
			if(count($row)>0)
			{
				$tanggal  = $row[0]->tanggal;
				$newDate  = $this->cekJamMasuk($tanggal);
				
				return $newDate;
			}else{
				return 0;
			}
			
	 }
	 
	 function getAbsenHarianPulang($id_pegawai, $tgl)
	 {
			$sql = "SELECT tanggal FROM ts_absensi WHERE id_pegawai = '$id_pegawai' AND date(tanggal) = '$tgl' ORDER BY tanggal DESC limit 1";
			$qry = $this->db->query($sql);
			$row = $qry->result();
			
			if(count($row)>0)
			{
				$tanggal  = $row[0]->tanggal;
				$newDate  = $this->cekJamKeluar($tanggal);
				return $newDate;
			}else{
				return 0;
			}
			
	 }
	 
	 
	 
	
	 
	 
	 
	function getAbsesnsiPerhari($id_pegawai, $tgl, $status)
	{	
	    if($status==0)
		{
			$order_by = "tanggal ASC limit 1";
			$and = "AND transaksi = 0";
		}else{
			$order_by = "tanggal DESC limit 1";
			$and = "AND transaksi = 1";
		}
		

	    $sql = "SELECT tanggal FROM ts_absensi WHERE id_pegawai like '$id_pegawai' AND date(tanggal) = '$tgl' $and  ORDER BY  $order_by";
		
		/*echo $sql;
		echo '<br>';*/
		
        $qry = $this->db->query($sql);
        $row = $qry->result();
		
		if(count($row)>0)
		{
			$tanggal = $row[0]->tanggal;
			/*
			if($status==0)
			{
				//masuk
				$newDate = $this->cekJamMasuk($tanggal);
			}else{
				//pulang
				$newDate  = $this->cekJamKeluar($tanggal);
			
			}
			*/
			
			return $tanggal;
		}else{
			return 0;
		}
		
		
	}
	
	
	function getDataShift($id_pegawai, $tgl, $bln_tahun)
	{
		 $sql = "SELECT b.*, a.id AS id_ts_shift   FROM ts_shift_kerja a LEFT JOIN mst_shift_kerja b
		 ON a.shift = b.shift 
		 WHERE id_pegawai = '$id_pegawai' AND tanggal = '$tgl' AND bulan_tahun = '$bln_tahun' ORDER BY id ASC LIMIT 1 OFFSET 0";
		
		 $qry = $this->db->query($sql);
         $row = $qry->result();
		
		 return $row;
	}
	
	
	
	
	
	
	 function cekJamMasuk($date)
	 {
		 $expl = explode(":", $date);
		 $time = $expl[0];
		 
		 $time = substr($time, 11, 2);
		 	
		 
		 if($time > 13)
		 {
			 $newTime = '';
		 }else{
			 $newTime = $date;
		 }
		 
		 if($date=='')
		 {
			 $newTime = 0;
		 }
		 
		 return $newTime;
	 }
	 
	  function cekJamKeluar($date)
	 {
		 
		 
		 $expl = explode(":", $date);
		 $time = $expl[0];
		 $time = substr($time, 11, 2);
		 
		 if($time < 13)
		 {
			 $newTime = '';
		 }else{
			 $newTime = $date;
		 }
		 
		  if($date=='')
		 {
			 $newTime = 0;
		 }
		 
		 return $newTime;
	 }
	
	
	
	
	
	
	
	
	
	 function getDataAbsesnsiPegawai($id_pegawai)
	{
		$tahun = '2018';
		$bulan = '02';
        $sql = "SELECT * FROM `log_upload_absensi` WHERE id_pegawai = '$id_pegawai' AND year(tgl_absen) ='$tahun' AND month(tgl_absen) = '$bulan'  ORDER BY tgl_absen ASC ";
        $qry = $this->db->query($sql);
        $row = $qry->result();
		return $row;
	}
	
	 public function cekTglInput($tgl, $UID, $Status)
     {		
			
		    $query  = "SELECT id from ts_absensi  WHERE date(tanggal) = '$tgl' AND id_pegawai = '$UID' AND transaksi  = '$Status' ";
			$result = $this->db->query($query);
			$num 	= mysqli_num_rows($result);
			
			
		  return  $num;
     }
	 
	 
	 
	 
	function cekKegPeg($id_peg, $id_akt)
	{
		
		$sql = "SELECT id FROM aktifitas_pegawai WHERE id_pegawai = '$id_peg' AND id_aktifitas = $id_akt";
		$qry = $this->db->query($sql);
		$row = $qry->num_rows();
	
		if($row ==0)
		{
			return false;
		}else{
			return true;
		}
	}
	
	 
	
	
	
}
?>
