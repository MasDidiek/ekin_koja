<!DOCTYPE html>
<html lang="en">

<?php $this->load->view('admin/master/meta');?>
    <link rel="stylesheet" type="text/css" href="//cdn.datatables.net/1.13.1/css/jquery.dataTables.min.css">
    <link rel="stylesheet" href="//code.jquery.com/ui/1.13.2/themes/base/jquery-ui.css">

<body>
	<div class="wrapper">
	
    <?php $this->load->view('admin/master/navbar');?>
			<main class="content">
				<div class="container-fluid p-0">

					<h1 class="h3 mb-3">Pengemudi</h1>

                    
					<div class="row">
						<div class="col-12 col-lg-12 col-xxl-12">
							<div class="card">
								<div class="card-header">
                                        
                                        <a href="<?php echo base_url();?>admin/admin_driver/add_driver" class="btn btn-info float-end"> <i class="align-middle" data-feather="plus"></i>  Input Pengemudi</a>
								
								</div>
								
								<div class="card-body">
							    	<table class="table table-hover" id="dataTable">
								  	  <thead>
									     <tr>
                                                <th>No</th>
                                                <th align="center">Tanggal Daftar</th>
                                                <th align="center">No KTP</th>
                                                <th align="left">Nama</th>
                                                <th align="center">Tgl Lahir</th>
                                                <th align="center">L/P</th>       
                                                <th align="center">Nama PO</th>
                                                <th align="center">Status</th>
                                                <th align="center">Petugas</th>
                                            </tr>
    								  	</thead>
    									<tbody>
    									    
									      <?php
                                                $no = 0;
                                                for ($i=0; $i < count($driver) ; $i++) { 
                                                    
                                                        $status_pemeriksaan = $driver[$i]->status_pemeriksaan;
                    
                                                        if($status_pemeriksaan==0){
                                                            $status_periksa = '<span class="badge badge-warning-light">Belum diperiksa</span>';
                                                        }else{
                                                            $status_periksa = '<span class="badge badge-success-light">Sudah diperiksa</span>'; 
                                                        }
                                                        
                                                        
                                                    $no = $i+1;
                                                    echo ' <tr>
                                                            <td align="center">'.$no .'</td>
                                                            <td align="center">'.format_view($driver[$i]->tgl_daftar).'</td>
                                                            <td align="center">'.$driver[$i]->no_ktp.'</td>
                                                            
                                                            <td>
                                                                <a href="'.base_url().'admin/admin_driver/detail/'.$driver[$i]->id.'" class="text-link">'.$driver[$i]->nama.'</a></td>
                                                            <td align="center">'.format_view($driver[$i]->tgl_lahir).'</td>
                                                            <td  align="center">'.$driver[$i]->jns_kel.'</td>
                                                            <td  align="left">'.$driver[$i]->nama_po.'</td>
                                                            <td  align="center">
                                                                '.$status_periksa.'
                                                            </td>
                                                            <td>'.$driver[$i]->petugas.'</td>
                                                            
                                                        </tr>';
                                                }
                                            ?>
                                            

									   
									</tbody>
								</table>
								
									</div>
							</div>
						</div>
						
					</div>

				</div>
			</main>

			<footer class="footer">
				<div class="container-fluid">
					<div class="row text-muted">
						<div class="col-6 text-start">
							<p class="mb-0">
								<a class="text-muted" href="https://adminkit.io/" target="_blank"><strong>AdminKit</strong></a> - <a class="text-muted" href="https://adminkit.io/" target="_blank"><strong>Bootstrap Admin Template</strong></a>								&copy;
							</p>
						</div>
						<div class="col-6 text-end">
							<ul class="list-inline">
								<li class="list-inline-item">
									<a class="text-muted" href="https://adminkit.io/" target="_blank">Support</a>
								</li>
								<li class="list-inline-item">
									<a class="text-muted" href="https://adminkit.io/" target="_blank">Help Center</a>
								</li>
								<li class="list-inline-item">
									<a class="text-muted" href="https://adminkit.io/" target="_blank">Privacy</a>
								</li>
								<li class="list-inline-item">
									<a class="text-muted" href="https://adminkit.io/" target="_blank">Terms</a>
								</li>
							</ul>
						</div>
					</div>
				</div>
			</footer>
		</div>
	</div>

	<script src="<?php echo base_url();?>assets/js/app.js"></script>


<!-- Scripts below are for demo only -->
<script src="https://code.jquery.com/jquery-3.6.0.js"></script>
  <script src="https://code.jquery.com/ui/1.13.2/jquery-ui.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/js/main.min.js?v=1628755089081"></script>
<script src="//cdn.datatables.net/1.11.3/js/jquery.dataTables.min.js"></script>

</body>


<script>


   
$(document).ready(function(){
  
        
  $('#dataTable').DataTable({
    "pageLength": 10
  });


  $( function() {
        $( "#datepicker" ).datepicker({
            dateFormat : "dd-mm-yy",
          changeMonth: true
        });
    } );

  $("#filter_bydatae").click(function(){
        $(this).html('loading');
       
        var tgl = $("#datepicker").val();


        $.ajax({
            type: "POST",
            dataType: "html",
            url: "<?php echo  base_url() . 'admin/admin_driver/create_session_date'; ?>",
            data: "tgl=" + tgl,
            success: function(msg) {
                window.location.reload();
            }
        });

    });

});

</script>
</html>