<!DOCTYPE html>
<html lang="en">

<?php $this->load->view('admin/master/meta');?>
    <link rel="stylesheet" type="text/css" href="//cdn.datatables.net/1.13.1/css/jquery.dataTables.min.css">
    <link rel="stylesheet" href="//code.jquery.com/ui/1.13.2/themes/base/jquery-ui.css">

<body>
	<div class="wrapper">
	
    <?php $this->load->view('admin/master/navbar');?>
			<main class="content">
				<div class="container-fluid p-0">

					<h1 class="h3 mb-3">Pengemudi</h1>

                    
                            
                       <?php
                            $id_driver =  $data_detail[0]->id;
                            $status_kawin =  $data_detail[0]->status_kawin;
                            if($status_kawin=='BM'){
                                $s_nikah = 'Belum Menikah';
                            }else if($status_kawin=='M'){
                                $s_nikah = 'Menikah';
                            }else if($status_kawin=='D'){
                                $s_nikah = 'Duda';
                            }else{
                                $s_nikah = 'Janda';
                            }
        
                
                      ?>
        
        

					<div class="row">
						<div class="col-12 col-lg-12 col-xxl-12">
							<div class="card">
								<div class="card-header">
                                 <a href="<?php echo base_url();?>admin/admin_driver/index" class="btn btn-light border float-start  mr-2"><i class="align-middle" data-feather="corner-up-left"></i> Kembali </a>
                                 <a href="<?php echo base_url();?>admin/admin_driver/ubah_data_pengemudi/<?php echo $data_detail[0]->id;?>" class="btn btn-info float-end  mr-2"><i class="align-middle" data-feather="edit"></i>   Ubah Data </a>
                                <a href="<?php echo base_url();?>admin/admin_driver/delete/<?php echo $id_driver;?>" onClick="return confirm('Hapus data pengemudi ini?');" class="btn btn-danger float-end me-2">
                                      <i class="align-middle" data-feather="trash"></i>  Hapus               
                                </a>
                                <div class="clearfix"></div>
                                <br>  
                                  <table class="infotable table-sm">
                                    <tr>
                                        <td width="200">Nama</td>
                                        <td width="20">:</td>
                                        <td><strong><?php echo $data_detail[0]->nama;?></strong></td>
                                    </tr>
                                    <tr>
                                        <td>NIK</td>
                                        <td>:</td>
                                        <td><?php echo $data_detail[0]->no_ktp;?></td>
                                    </tr>
                                    <tr>
                                        <td>Tanggal Lahir</td>
                                        <td>:</td>
                                        <td><?php echo $data_detail[0]->tgl_lahir;?></td>
                                    </tr>
                                    <tr>
                                        <td>Jenis Kelamin</td>
                                        <td>:</td>
                                        <td><?php echo $data_detail[0]->jns_kel;?></td>
                                    </tr>
                                    <tr>
                                        <td>No HP</td>
                                        <td>:</td>
                                        <td><?php echo $data_detail[0]->no_hp;?></td>
                                    </tr>
                                    <tr>
                                        <td>Alamat</td>
                                        <td>:</td>
                                        <td><?php echo $data_detail[0]->alamat;?></td>
                                    </tr>
                                    <tr>
                                        <td>Status Pernikahan</td>
                                        <td>:</td>
                                        <td><?php echo $s_nikah;?></td>
                                    </tr>
                                    <tr>
                                        <td>Pendidikan</td>
                                        <td>:</td>
                                        <td><?php echo $data_detail[0]->pendidikan;?></td>
                                    </tr>
                                    <tr>
                                        <td>Pekerjaan</td>
                                        <td>:</td>
                                        <td><?php echo $data_detail[0]->pekerjaan;?></td>
                                    </tr>
            
                                    <tr>
                                            <td width="200">Nama PO </td>
                                            <td width="20">:</td>
                                            <td><?php echo $data_detail[0]->nama_po;?></td>
                                        </tr>
                                        <tr>
                                            <td>Status Supir</td>
                                            <td>:</td>
                                            <td><?php echo $data_detail[0]->status_supir;?></td>
                                        </tr>
                                </table>
								</div>
								
								
								
								<div class="card-body">
							         
							        
									<div class="modal fade" id="defaultModalPrimary" tabindex="-1" role="dialog" aria-hidden="true">
										<div class="modal-dialog" role="document">
											<div class="modal-content">
												<div class="modal-header">
													<h5 class="modal-title">Detail Pemeriksaan</h5>
												
												</div>
												<div class="modal-body m-3" id="content-modal">
													<p class="mb-0"></p>
												</div>
												<div class="modal-footer">
													<button type="button" class="btn btn-secondary float-end" data-bs-dismiss="modal">Close</button>
													<div class="clearfix"></div>
												
												</div>
											</div>
										</div>
									</div>
									
									
                                         <a href="<?php echo base_url();?>admin/admin_driver/periksa/<?php echo $id_driver;?>" class="btn btn-primary float-end me-2">
                                              <i class="align-middle" data-feather="edit"></i>   Periksa Pengemudi                    
                                        </a>
                                        
                                        <br>
                                        <h3>Riwayat Pemeriksaan</h3>
                        
                                        <table class="table">
                                            <tr>
                                                <th>No</th>
                                                <th>Tanggal Periksa</th>
                                                <th>Hipertensi</th>
                                                <th>Gula Darah</th>
                                                <th>Status Laik</th>
                                                <th>Terminal</th>
                                                <th>Rujuk</th>
                                                <th>Petugas</th>
                                                <th>Action</th>
                                            </tr>
                        
                        
                                            <?php 
                                            for ($i=0; $i < count($history); $i++) {
                                                $id = $history[$i]->id;
                                                $tgl_periksa = $history[$i]->date_time;
                                                $status_ht = $history[$i]->status_ht;
                                                $status_gds = $history[$i]->status_gds;
                                                $status_laik = $history[$i]->status_laik;
                                                $petugas = $history[$i]->petugas;
                                                $rujuk = $history[$i]->rujuk;
                        
                                                $tensi_sistol = $history[$i]->tensi_sistol;
                                                $tensi_diastol = $history[$i]->tensi_diastol;
                                                $nama_terminal = $history[$i]->nama_terminal;
                                                $gds = $history[$i]->gds;
                        
                        
                                                $flagHT = getFlagHT($status_ht);
                                                $flagGDS = getFlagGDS($status_gds);
                                                $flagLaik = getFlagLaik($status_laik);
                        
                                                if($rujuk==1){
                                                    $status_rujuk = '<i class="fas fa-check"></i>';
                                                }else{
                                                    $status_rujuk = '';
                                                }
                        
                                            echo ' <tr>
                                                        <td align="center">'.($i+1).'</td>
                                                        <td align="center">'. $tgl_periksa.'</td>
                                                        <td align="center">'.$flagHT.'</td>
                                                        <td align="center">'.$flagGDS.'</td>
                                                        <td align="center">'.$flagLaik.'</td>
                                                    
                                                        <td>'.$nama_terminal.'</td>
                                                        <td align="center">'.$status_rujuk.'</td>
                                                        <td>'. $petugas .'</td>
                                                        <td>
                                                             <button type="button" value="'.$id.'" class="btn btn-info lihat-detail" data-bs-toggle="modal" data-bs-target="#defaultModalPrimary">
                        									 Detail
                        									</button>
                                                        </td>
                                                    </tr>';
                                            }
                                        
                                        ?>
                                        </table>
								</div>
							</div>
						</div>
						
					</div>

				</div>
			</main>

			<footer class="footer">
				<div class="container-fluid">
					<div class="row text-muted">
						<div class="col-6 text-start">
							<p class="mb-0">
								<a class="text-muted" href="https://adminkit.io/" target="_blank"><strong>AdminKit</strong></a> - <a class="text-muted" href="https://adminkit.io/" target="_blank"><strong>Bootstrap Admin Template</strong></a>								&copy;
							</p>
						</div>
						<div class="col-6 text-end">
							<ul class="list-inline">
								<li class="list-inline-item">
									<a class="text-muted" href="https://adminkit.io/" target="_blank">Support</a>
								</li>
								<li class="list-inline-item">
									<a class="text-muted" href="https://adminkit.io/" target="_blank">Help Center</a>
								</li>
								<li class="list-inline-item">
									<a class="text-muted" href="https://adminkit.io/" target="_blank">Privacy</a>
								</li>
								<li class="list-inline-item">
									<a class="text-muted" href="https://adminkit.io/" target="_blank">Terms</a>
								</li>
							</ul>
						</div>
					</div>
				</div>
			</footer>
		</div>
	</div>

	<script src="<?php echo base_url();?>assets/js/app.js"></script>


<!-- Scripts below are for demo only -->
<script src="https://code.jquery.com/jquery-3.6.0.js"></script>
  <script src="https://code.jquery.com/ui/1.13.2/jquery-ui.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/js/main.min.js?v=1628755089081"></script>
<script src="//cdn.datatables.net/1.11.3/js/jquery.dataTables.min.js"></script>

</body>


<script>


   
$(document).ready(function(){
  
        
  $('#dataTable').DataTable({
    "pageLength": 10
  });


  $( function() {
        $( "#datepicker" ).datepicker({
            dateFormat : "dd-mm-yy",
          changeMonth: true
        });
    } );



  $(".lihat-detail").click(function(){
       
       
        var id = $(this).val();
        $.ajax({
            type: "POST",
            dataType: "html",
            url: "<?php echo  base_url() . 'admin/admin_driver/detail_pemeriksaan/'; ?>",
            data: "id=" + id,
            success: function(msg) {
               $("#content-modal").html(msg)
            }
        });

    });



  $("#filter_bydatae").click(function(){
        $(this).html('loading');
       
        var tgl = $("#datepicker").val();


        $.ajax({
            type: "POST",
            dataType: "html",
            url: "<?php echo  base_url() . 'admin/admin_driver/create_session_date'; ?>",
            data: "tgl=" + tgl,
            success: function(msg) {
                window.location.reload();
            }
        });

    });

});

</script>
</html>